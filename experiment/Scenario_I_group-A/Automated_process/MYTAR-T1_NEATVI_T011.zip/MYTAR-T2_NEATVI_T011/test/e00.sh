# vi commands
echo    ":w $1"
echo    ":q"

# vi commands
output_file="text_output.txt"

echo    ":i"
echo    "abc"
echo    "."
echo    ":w $output_file"
echo    ":q!"
# the expected output

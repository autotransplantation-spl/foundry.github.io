
#include "vi.h"

#include "conf.h"

#include "kmap.h"

#include "regex.h"

#include "InterfaceHeader.h"

void dir_init_GRAFT_INTERFACE (char *$_host_argv [], char *$_host_prog, int $_host_argc, int $_host_i) {
    dir_init ();
}

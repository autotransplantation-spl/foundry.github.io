var conf_8c =
[
    [ "conf_dirmark", "conf_8c.html#a3efe6ef9cd3bd043b3df1653265409f2", null ],
    [ "conf_dircontext", "conf_8c.html#a9e1bc5ed600c151c51d8e2342454e07c", null ],
    [ "conf_placeholder", "conf_8c.html#ab1da6502eeb02af2fb9fa8a84515b0b6", null ],
    [ "conf_highlight", "conf_8c.html#a16ebf87f52698ee8c6b831cd629fb3b8", null ],
    [ "conf_filetype", "conf_8c.html#a1a3b977b82bc19d19926e54e4f9de9ba", null ],
    [ "conf_hlrev", "conf_8c.html#a3eba9139f1834af92b8aa5798b7bb245", null ],
    [ "conf_hlline", "conf_8c.html#a2932014471edf4f088882f31de3325a7", null ],
    [ "conf_mode", "conf_8c.html#a68ed8ae4297d73ab9ec46791d76a6868", null ],
    [ "conf_kmap", "conf_8c.html#a701ceb92f75bae1a0d9d805796eb2f84", null ],
    [ "conf_kmapfind", "conf_8c.html#aa4f8c081bd561272a1c0c1268ca6c273", null ],
    [ "conf_digraph", "conf_8c.html#acbeed8b0b62960a541af67e17d6c7131", null ]
];
/* rendering strings */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vi.h"

/* specify the screen position of the characters in s */
#ifdef F_DIR_INIT_TOO
int *ren_position(char *s)
{
	int i, n;
	char **chrs = uc_chop(s, &n);
	int *off, *pos;
	int cpos = 0;
	pos = malloc((n + 1) * sizeof(pos[0]));
	for (i = 0; i < n; i++)
		pos[i] = i;
	if (xorder)
		dir_reorder(s, pos);
	off = malloc(n * sizeof(off[0]));
	for (i = 0; i < n; i++)
		off[pos[i]] = i;
	for (i = 0; i < n; i++) {
		pos[off[i]] = cpos;
		cpos += ren_cwid(chrs[off[i]], cpos);
	}
	pos[n] = cpos;
	free(chrs);
	free(off);
	return pos;
}
#end

#ifdef F_DIR_INIT_TOO
int ren_wid(char *s)
{
	int *pos = ren_position(s);
	int n = uc_slen(s);
	int ret = pos[n];
	free(pos);
	return ret;
}
#end

/* find the next character after visual position p; if cur, start from p itself */
#ifdef F_DIR_INIT_TOO
static int pos_next(int *pos, int n, int p, int cur)
{
	int i, ret = -1;
	for (i = 0; i < n; i++)
		if (pos[i] - !cur >= p && (ret < 0 || pos[i] < pos[ret]))
			ret = i;
	return ret >= 0 ? pos[ret] : -1;
}
#end

/* find the previous character after visual position p; if cur, start from p itself */
#ifdef F_DIR_INIT_TOO
static int pos_prev(int *pos, int n, int p, int cur)
{
	int i, ret = -1;
	for (i = 0; i < n; i++)
		if (pos[i] + !cur <= p && (ret < 0 || pos[i] > pos[ret]))
			ret = i;
	return ret >= 0 ? pos[ret] : -1;
}
#end

/* convert character offset to visual position */
#ifdef F_DIR_INIT_TOO
int ren_pos(char *s, int off)
{
	int n = uc_slen(s);
	int *pos = ren_position(s);
	int ret = off < n ? pos[off] : 0;
	free(pos);
	return ret;
}
#end

/* convert visual position to character offset */
#ifdef F_DIR_INIT_TOO
int ren_off(char *s, int p)
{
	int off = -1;
	int n = uc_slen(s);
	int *pos = ren_position(s);
	int i;
	p = pos_prev(pos, n, p, 1);
	for (i = 0; i < n; i++)
		if (pos[i] == p)
			off = i;
	free(pos);
	return off >= 0 ? off : 0;
}
#end

/* adjust cursor position */
#ifdef F_DIR_INIT_TOO
int ren_cursor(char *s, int p)
{
	int n, next;
	int *pos;
	if (!s)
		return 0;
	n = uc_slen(s);
	pos = ren_position(s);
	p = pos_prev(pos, n, p, 1);
	if (uc_code(uc_chr(s, ren_off(s, p))) == '\n')
		p = pos_prev(pos, n, p, 0);
	next = pos_next(pos, n, p, 0);
	p = (next >= 0 ? next : pos[n]) - 1;
	free(pos);
	return p >= 0 ? p : 0;
}
#end

/* return an offset before EOL */
#ifdef F_DIR_INIT_TOO
int ren_noeol(char *s, int o)
{
	int n = s ? uc_slen(s) : 0;
	if (o >= n)
		o = MAX(0, n - 1);
	return o > 0 && uc_chr(s, o)[0] == '\n' ? o - 1 : o;
}
#end

/* the position of the next character */
#ifdef F_DIR_INIT_TOO
int ren_next(char *s, int p, int dir)
{
	int n = uc_slen(s);
	int *pos = ren_position(s);
	p = pos_prev(pos, n, p, 1);
	if (dir >= 0)
		p = pos_next(pos, n, p, 0);
	else
		p = pos_prev(pos, n, p, 0);
	free(pos);
	return s && uc_chr(s, ren_off(s, p))[0] != '\n' ? p : -1;
}
#end

#ifdef F_DIR_INIT_TOO
static char *ren_placeholder(char *s)
{
	char *src, *dst;
	int wid, i;
	int c = uc_code(s);
	for (i = 0; !conf_placeholder(i, &src, &dst, &wid); i++)
		if (uc_code(src) == c)
			return dst;
	if (uc_iscomb(s)) {
		static char buf[16];
		char cbuf[8] = "";
		memcpy(cbuf, s, uc_len(s));
		sprintf(buf, "ـ%s", cbuf);
		return buf;
	}
	if (uc_isbell(s))
		return "�";
	return NULL;
}
#end

#ifdef F_DIR_INIT_TOO
int ren_cwid(char *s, int pos)
{
	char *src, *dst;
	int wid, i;
	if (s[0] == '\t')
		return 8 - (pos & 7);
	for (i = 0; !conf_placeholder(i, &src, &dst, &wid); i++)
		if (uc_code(src) == uc_code(s))
			return wid;
	return 1;
}
#end

#ifdef F_DIR_INIT_TOO
char *ren_translate(char *s, char *ln)
{
	char *p = ren_placeholder(s);
	return p || !xshape ? p : uc_shape(ln, s);
}
#end

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vi.h"

#define NFTS		16


/* mapping filetypes to regular expression sets */
static struct ftmap {
	char ft[32];
	struct rset *rs;
} ftmap[NFTS];

static struct rset *syn_ftrs;
static int syn_ctx;

static struct rset *syn_find(char *ft)
{
	int i;
	for (i = 0; i < LEN(ftmap); i++)
		if (!strcmp(ft, ftmap[i].ft))
			return ftmap[i].rs;
	return NULL;
}

#ifdef F_DIR_INIT_TOO
int syn_merge(int old, int new)
{
	int fg = SYN_FGSET(new) ? SYN_FG(new) : SYN_FG(old);
	int bg = SYN_BGSET(new) ? SYN_BG(new) : SYN_BG(old);
	return ((old | new) & SYN_FLG) | (bg << 8) | fg;
}
#end

#ifdef F_DIR_INIT_TOO
void syn_context(int att)
{
	syn_ctx = att;
}
#end

#ifdef F_DIR_INIT_TOO
int *syn_highlight(char *ft, char *s)
{
	int subs[16 * 2];
	int n = uc_slen(s);
	int *att = malloc(n * sizeof(att[0]));
	int sidx = 0;
	struct rset *rs = syn_find(ft);
	int flg = 0;
	int hl, j, i;
	memset(att, 0, n * sizeof(att[0]));
	if (!rs)
		return att;
	for (i = 0; i < n; i++)
		att[i] = syn_ctx;
	while ((hl = rset_find(rs, s + sidx, LEN(subs) / 2, subs, flg)) >= 0) {
		int grp = 0;
		int cend = 1;
		int *catt;
		conf_highlight(hl, NULL, &catt, NULL, &grp);
		for (i = 0; i < LEN(subs) / 2; i++) {
			if (subs[i * 2] >= 0) {
				int beg = uc_off(s, sidx + subs[i * 2 + 0]);
				int end = uc_off(s, sidx + subs[i * 2 + 1]);
				for (j = beg; j < end; j++)
					att[j] = syn_merge(att[j], catt[i]);
				if (i == grp)
					cend = MAX(cend, subs[i * 2 + 1]);
			}
		}
		sidx += cend;
		flg = RE_NOTBOL;
	}
	return att;
}
#end

#ifdef F_DIR_INIT_TOO
static void syn_initft(char *name)
{
	char *pats[128] = {NULL};
	char *ft, *pat;
	int i, n;
	for (i = 0; !conf_highlight(i, &ft, NULL, &pat, NULL) && i < LEN(pats); i++)
		if (!strcmp(ft, name))
			pats[i] = pat;
	n = i;
	for (i = 0; i < LEN(ftmap); i++) {
		if (!ftmap[i].ft[0]) {
			strcpy(ftmap[i].ft, name);
			ftmap[i].rs = rset_make(n, pats, 0);
			return;
		}
	}
}
#end

#ifdef F_DIR_INIT_TOO
char *syn_filetype(char *path)
{
	int hl = rset_find(syn_ftrs, path, 0, NULL, 0);
	char *ft;
	if (!conf_filetype(hl, &ft, NULL))
		return ft;
	return "";
}
#end

#ifdef F_DIR_INIT_TOO
void syn_init(void)
{
	char *pats[128] = {NULL};
	char *pat, *ft;
	int i;
	for (i = 0; !conf_highlight(i, &ft, NULL, NULL, NULL); i++)
		if (!syn_find(ft))
			syn_initft(ft);
	for (i = 0; !conf_filetype(i, NULL, &pat) && i < LEN(pats); i++)
		pats[i] = pat;
	syn_ftrs = rset_make(i, pats, 0);
}
#end

#ifdef F_DIR_INIT_TOO
void syn_done(void)
{
	int i;
	for (i = 0; i < LEN(ftmap); i++)
		if (ftmap[i].rs)
			rset_free(ftmap[i].rs);
	rset_free(syn_ftrs);
}
#end

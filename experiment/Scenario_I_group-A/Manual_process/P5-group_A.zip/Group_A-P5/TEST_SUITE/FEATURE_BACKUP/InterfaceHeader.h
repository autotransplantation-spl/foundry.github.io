
extern void dir_init (void);
void dir_init_GRAFT_INTERFACE (void);

var annotated_dup =
[
    [ "dircontext", "structdircontext.html", "structdircontext" ],
    [ "dirmark", "structdirmark.html", "structdirmark" ],
    [ "filetype", "structfiletype.html", "structfiletype" ],
    [ "highlight", "structhighlight.html", "structhighlight" ],
    [ "placeholder", "structplaceholder.html", "structplaceholder" ],
    [ "regmatch_t", "structregmatch__t.html", "structregmatch__t" ]
];
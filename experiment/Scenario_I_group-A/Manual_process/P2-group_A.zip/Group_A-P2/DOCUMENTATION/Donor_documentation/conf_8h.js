var conf_8h =
[
    [ "filetype", "structfiletype.html", "structfiletype" ],
    [ "highlight", "structhighlight.html", "structhighlight" ],
    [ "dircontext", "structdircontext.html", "structdircontext" ],
    [ "dirmark", "structdirmark.html", "structdirmark" ],
    [ "placeholder", "structplaceholder.html", "structplaceholder" ],
    [ "MKFILE_MODE", "conf_8h.html#a9592733ddcf3912f6b0ec36e5a71fecb", null ],
    [ "SYN_LINE", "conf_8h.html#a13e15ac7a37a168e5ee51e861d42489b", null ],
    [ "SYN_REVDIR", "conf_8h.html#a4eda9c8ae69f2d08cfa15389b8b86f9c", null ],
    [ "CR2L", "conf_8h.html#ab72ad76b427fe49957dc6959ea53d4c1", null ],
    [ "CNEUT", "conf_8h.html#a15b330ee9de65d4b56908f37ecb56d75", null ],
    [ "filetypes", "conf_8h.html#a2cc425d6e7b7275dad20442d2a0151a4", null ],
    [ "highlights", "conf_8h.html#a783f4ccad63f90b2d508c4713bd2ffee", null ],
    [ "dircontexts", "conf_8h.html#aae206e407233bf3d67d89637a97c07d5", null ],
    [ "dirmarks", "conf_8h.html#a5bb0264e2a8d9d488e17e8134d58c717", null ],
    [ "placeholders", "conf_8h.html#aa01fd4558f8683b75a80ff77e6b93507", null ]
];
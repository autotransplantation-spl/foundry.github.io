
#include "InterfaceHeader.h"

void dir_init_GRAFT_INTERFACE (void) {
   
    // insira seu codigo de adaptaçao aqui, caso necessário
    
  //  dir_init();
}


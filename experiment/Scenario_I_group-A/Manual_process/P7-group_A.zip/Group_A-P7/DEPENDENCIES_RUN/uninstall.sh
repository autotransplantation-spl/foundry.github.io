#!/bin/bash
#Uninstalling dependences
brew uninstall automake
brew uninstall check
brew uninstall glib

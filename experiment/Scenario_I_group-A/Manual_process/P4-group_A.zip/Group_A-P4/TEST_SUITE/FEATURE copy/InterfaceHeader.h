
#include <ctype.h>

#include <fcntl.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>


extern struct rset *dir_rslr;
extern struct rset *dir_rsrl;
extern struct rset *dir_rsctx;

extern void dir_init (void);
void dir_init_GRAFT_INTERFACE (char * $_host_argv [], char * $_host_prog, int $_host_argc, int $_host_i);

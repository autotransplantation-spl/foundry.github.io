var structplaceholder =
[
    [ "s", "structplaceholder.html#aa77b0005c6e567f5ff631cf55dc22213", null ],
    [ "d", "structplaceholder.html#a4da62f5af9f5893998994df1aa151487", null ],
    [ "wid", "structplaceholder.html#a316957c425536ccabbee4b0a2dd98fe0", null ]
];
var reg_8c =
[
    [ "reg_get", "reg_8c.html#a6eaa41c69e0e22bcbb189eaf4ff0feae", null ],
    [ "reg_putraw", "reg_8c.html#a7d863266d9fa9455f0ffa968f51d0ce3", null ],
    [ "reg_put", "reg_8c.html#a4a1ad2201f6bc8ca5faf958f146883d5", null ],
    [ "reg_done", "reg_8c.html#a8fb8e8a7f5d10e4b9edebfcd99d062f3", null ],
    [ "bufs", "reg_8c.html#ab3362781e47adf29610ac49ae66f607a", null ],
    [ "lnmode", "reg_8c.html#aea4daec7797c963a11280d77c5c3e6c9", null ]
];
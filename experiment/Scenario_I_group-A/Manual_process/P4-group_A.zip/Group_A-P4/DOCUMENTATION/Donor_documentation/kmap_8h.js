var kmap_8h =
[
    [ "kmap_en", "kmap_8h.html#a5813979f6de814ba979f156c594ad687", null ],
    [ "kmap_fa", "kmap_8h.html#adf070d5884901a8f9917505caf10047b", null ],
    [ "kmaps", "kmap_8h.html#a9eb90a55b6c1940f38b96f7904057d04", null ],
    [ "digraphs", "kmap_8h.html#a41a50ac08dcb9efde172a03737ed84d7", null ]
];
#!/bin/sh
SUCCESFUL=0
test_output_file=$1
rm -f $test_output_file
cd ..
cp -r -f *.c TRANSPLANTATION_TEST_CASES
cp -r -f *.h TRANSPLANTATION_TEST_CASES
cp -r -f Makefile TRANSPLANTATION_TEST_CASES
cd TRANSPLANTATION_TEST_CASES
rm -r -f *.o
#make > /dev/null 2>&1
if !(make > /dev/null 2>&1); then
    echo "ERROR: Source code is not compiling!\n"
    exit 1
fi

#EXECUTING REGRESSION TEST CASES
echo "EXECUTING REGRESSION TEST CASES" >> $test_output_file

if result=$(./test.sh) > /dev/null; then
    SUCCESFUL=1
fi
#print result in $test_output_file
echo "$result" >> $test_output_file
#show result
while IFS= read -r line; do
    echo "$line"
done <<< "$result"

echo "\nEXECUTING HOST POST-OPERATIVE TEST CASES" >> $test_output_file
#TESTING FEATURE AUGMENTED
cd test_AUGMENTED
if result=$(./test_AUGMENTED.sh) > /dev/null; then
    SUCCESFUL=1
fi
cd ..
#print result in $test_output_file
echo "$result" >> $test_output_file
#show result
while IFS= read -r line; do
    echo "$line"
done <<< "$result"

#TESTING FEATURE DIR_INIT
cd test_F_DIR
if result=$(./test_dir_init.sh) > /dev/null; then
    SUCCESFUL=1
fi
cd ..
#print result in $test_output_file
echo "$result" >> $test_output_file
#show result
while IFS= read -r line; do
    echo "$line"
done <<< "$result"

if [ $SUCCESFUL == 0 ]; then
 echo "All test passed!!"
else
 echo "One or more tests filed!"
fi
rm -r -f *.h
rm -r -f *.c
rm -r -f *.o
rm -r -f vi
exit $SUCCESFUL

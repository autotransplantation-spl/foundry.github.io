var globals_func =
[
    [ "b", "globals_func.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "j", "globals_func_j.html", null ],
    [ "k", "globals_func_k.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ],
    [ "u", "globals_func_u.html", null ],
    [ "v", "globals_func_v.html", null ],
    [ "w", "globals_func_w.html", null ]
];
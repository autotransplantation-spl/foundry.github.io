var ren_8c =
[
    [ "ren_position", "ren_8c.html#af6e197881adec94ce251c84adf3dd495", null ],
    [ "ren_wid", "ren_8c.html#a887acd2e2c8513cfbb7e27f69d9835a7", null ],
    [ "pos_next", "ren_8c.html#ae6c30ee4fcc67460391eaa8adc182241", null ],
    [ "pos_prev", "ren_8c.html#af4201a7e1018cbf68ff5e009005ff8bd", null ],
    [ "ren_pos", "ren_8c.html#ab66e6a45a074bd54643b4c6fba4abfe4", null ],
    [ "ren_off", "ren_8c.html#a6fb670084750c8934454722b630e0caa", null ],
    [ "ren_cursor", "ren_8c.html#aa37d51760ec8c06d251bfb9f4a134f7a", null ],
    [ "ren_noeol", "ren_8c.html#a28bfe0435a7922335e67ebd5258beb13", null ],
    [ "ren_next", "ren_8c.html#aa288077162077d17ddd836c0167a2ad0", null ],
    [ "ren_placeholder", "ren_8c.html#a0b410d82df4f40183b9655f3a0c4750b", null ],
    [ "ren_cwid", "ren_8c.html#a319a71758607f19d2beedd2bd4d3b369", null ],
    [ "ren_translate", "ren_8c.html#a51d018012e29caa2b526a949b1f52fab", null ]
];
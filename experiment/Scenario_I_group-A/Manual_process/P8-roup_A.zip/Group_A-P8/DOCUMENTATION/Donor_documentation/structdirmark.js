var structdirmark =
[
    [ "ctx", "structdirmark.html#a27be75135b987a4b4556e888a3f065f9", null ],
    [ "dir", "structdirmark.html#a9020f30e1433b12d615240b54fc97bfc", null ],
    [ "grp", "structdirmark.html#aef346a11e5872833121f346c5ac20611", null ],
    [ "pat", "structdirmark.html#a88e1ca8853e5e18c4a96819a9df9b06a", null ]
];
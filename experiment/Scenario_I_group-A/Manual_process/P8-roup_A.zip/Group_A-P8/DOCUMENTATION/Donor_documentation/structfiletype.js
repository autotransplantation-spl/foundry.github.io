var structfiletype =
[
    [ "ft", "structfiletype.html#adfb3b6b4d8da4826e06624186a64dbe8", null ],
    [ "pat", "structfiletype.html#a059e465c26d08322250f48b21fda9564", null ]
];
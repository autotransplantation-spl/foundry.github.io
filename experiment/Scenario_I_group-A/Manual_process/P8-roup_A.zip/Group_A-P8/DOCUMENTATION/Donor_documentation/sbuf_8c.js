var sbuf_8c =
[
    [ "SBUFSZ", "sbuf_8c.html#a4e0544e791dccf6bc7ca88141e26cbc1", null ],
    [ "ALIGN", "sbuf_8c.html#a3496ca93085a056b9c18f7eb58179e28", null ],
    [ "NEXTSZ", "sbuf_8c.html#a1e0b3dca7e3572709aa4f3a0f85b4c3a", null ],
    [ "sbuf_extend", "sbuf_8c.html#a4ad75f3948c0340c342a3ea3eb63a6e6", null ],
    [ "sbuf_make", "sbuf_8c.html#a57748585d6786a2c1aadc2cbe6f2135b", null ],
    [ "sbuf_buf", "sbuf_8c.html#a4e56760893d5a6797626743840c9adf2", null ],
    [ "sbuf_done", "sbuf_8c.html#a7bf14d501d36ce36ee269d77cf2c3fc6", null ],
    [ "sbuf_free", "sbuf_8c.html#a8c1a89868b1999663effb78b4f3fab32", null ],
    [ "sbuf_chr", "sbuf_8c.html#a3f9aa15ca1d73f585d7a4a9d023e58ce", null ],
    [ "sbuf_mem", "sbuf_8c.html#aa511ac77d6b486accc01c0512ef27ed2", null ],
    [ "sbuf_str", "sbuf_8c.html#a603d1d6ab090025f5850f10bfa2dec7a", null ],
    [ "sbuf_len", "sbuf_8c.html#af4ad9608dfc956bbedc19df5c8256fc4", null ],
    [ "sbuf_cut", "sbuf_8c.html#a6450326142280a9dfda60fe773c0c152", null ],
    [ "sbuf_printf", "sbuf_8c.html#a4d9ed68cd21ab9787f69e9e6773b81d7", null ]
];
#!/bin/bash
#Uninstalling dependences
brew uninstall automake
brew uninstall autoconf
brew uninstall check
brew uninstall glib

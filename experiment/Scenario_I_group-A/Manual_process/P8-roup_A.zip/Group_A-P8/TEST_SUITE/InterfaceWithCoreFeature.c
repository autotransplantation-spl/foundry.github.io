
#include "vi.h"

#include "conf.h"

#include "kmap.h"

#include "regex.h"

#include "InterfaceHeader.h"

void dir_init_GRAFT_INTERFACE () {
    dir_init ();
}


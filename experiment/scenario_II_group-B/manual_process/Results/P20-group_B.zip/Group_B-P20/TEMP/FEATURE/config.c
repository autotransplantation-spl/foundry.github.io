#include "archiver.h"

int process_command_line (struct archive *a, int argc, char **argv) {
    int option_index = 1;
    a->append_files_count = 1;
   //a->command = COM_CREATE;
    a->fmode = O_RDWR | O_CREAT | O_EXCL;
    char *archiveFileName;
    archiveFileName = optarg;
    a->file_name = archiveFileName;
    return 1;
}



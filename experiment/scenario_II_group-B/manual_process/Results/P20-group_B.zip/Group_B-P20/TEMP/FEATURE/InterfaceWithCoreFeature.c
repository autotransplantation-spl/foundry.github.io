#include "InterfaceHeader.h"
#include "archiver.h"

struct archive archive = {0};

void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_path, char *$_host_s) {
    
	//insira aqui seu código de adaptação
	char *argv[3] = {$_host_ec, $_host_path, $_host_s};
	
	process_command_line (& archive, 3, argv);
    open_archive_file (& archive);
   
	char *in_file = argv[2];
    
    write_archive (in_file, & archive);
}


var structarchive =
[
    [ "command", "structarchive.html#a4e94f1d6313559df2736e420270d51c4", null ],
    [ "file_name", "structarchive.html#af53ad058f7eb0910f080a1f4f915c0e9", null ],
    [ "fmode", "structarchive.html#a85001a053208cfcb1068657d63aaafa9", null ],
    [ "fd", "structarchive.html#a5b70be4e0015788d23155f35025fa6cc", null ],
    [ "files_count", "structarchive.html#ae66def4e85421d65fc93a76fbd5bdb25", null ],
    [ "append_files_count", "structarchive.html#a0e5a488b370821feadf1d78d41f88343", null ],
    [ "headers_offset", "structarchive.html#ad50c4d2d11307d8e3a7dcc9e565a6134", null ],
    [ "file_descriptors", "structarchive.html#ab807b3dfec054d7cf43ce9912b6f8375", null ]
];
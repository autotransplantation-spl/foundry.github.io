var files_dup =
[
    [ "append.c", "append_8c.html", "append_8c" ],
    [ "archiver.h", "archiver_8h.html", "archiver_8h" ],
    [ "config.c", "config_8c.html", "config_8c" ],
    [ "header.c", "header_8c.html", "header_8c" ],
    [ "io.c", "io_8c.html", "io_8c" ],
    [ "list.c", "list_8c.html", "list_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];
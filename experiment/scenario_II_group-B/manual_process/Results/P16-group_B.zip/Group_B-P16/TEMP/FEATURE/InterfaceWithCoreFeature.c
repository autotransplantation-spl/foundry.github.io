#include "InterfaceHeader.h"
#include "archiver.h"

void write_archive_GRAFT_INTERFACE (char *in_file, struct archive *archive) {
    
    //insira aqui seu código de adaptação
   
   /* descomente a linha abixo para chamar a função write_arquivo. Insira os parametro necessários */
   write_archive (in_file, archive);
}


#!/bin/bash

make clean
make

./vi TEXT.txt
i
FILE.in
[ESC] :wa
 



var structhighlight =
[
    [ "ft", "structhighlight.html#ad7a9d2c639a5e9aca47bb7a8a1df1a6f", null ],
    [ "att", "structhighlight.html#ae3a34fc10444e26c737f6195b1f21550", null ],
    [ "pat", "structhighlight.html#ae8110c96404e595194b765ee24aa6704", null ],
    [ "end", "structhighlight.html#ab6610b2d6887cc305f3790abf784df43", null ]
];
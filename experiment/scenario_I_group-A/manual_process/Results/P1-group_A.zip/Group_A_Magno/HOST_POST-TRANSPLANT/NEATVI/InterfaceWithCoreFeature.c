
#include "InterfaceHeader.h"
struct archive archive = {0};
void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_outputFileName, char *$_host_fileIn) {
	//__INSIRA AQUI O CODIGO DE INICIALICAÇAO DAS VARIÁVEIS E A CHAMDA PARA A FUNÇÃO write_archive+-
    archive->file_name = _host_outputFileName;
    
    write_archive (in_file, & archive);
}


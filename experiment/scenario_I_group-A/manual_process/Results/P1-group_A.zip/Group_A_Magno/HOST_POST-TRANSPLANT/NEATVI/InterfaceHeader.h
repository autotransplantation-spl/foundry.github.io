
#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <check.h>

#include "vi.h"
void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_outputFileName, char *$_host_fileIn)  ;

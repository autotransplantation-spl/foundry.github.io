var syn_8c =
[
    [ "NFTS", "syn_8c.html#aab929e29e21787cec54cb2f43be09eb2", null ],
    [ "syn_find", "syn_8c.html#aeb0e8fff89077c709508b89c2d80fcd1", null ],
    [ "syn_merge", "syn_8c.html#a3c3478da43bbbba6173c2cc5e8c0ead3", null ],
    [ "syn_context", "syn_8c.html#ad9ea7d049558ca28203355649e9dd625", null ],
    [ "syn_highlight", "syn_8c.html#a00a481d2236c7c7fc489606a4ebe6de0", null ],
    [ "syn_initft", "syn_8c.html#a6e5fc3b0777302300322f64f2c7f0142", null ],
    [ "syn_filetype", "syn_8c.html#ad440dafd3cad961222bb22b9743657bf", null ],
    [ "syn_init", "syn_8c.html#a5ca5f67cbe20ba50389c586990d3582c", null ],
    [ "syn_done", "syn_8c.html#ac6e7a6d77f4896adf3a3ce36e0bb1573", null ],
    [ "ftmap", "syn_8c.html#a073ac406ec01c285c4862ce6112e0b24", null ],
    [ "syn_ftrs", "syn_8c.html#a87652c8dfa60752270fa83511da1bc6e", null ],
    [ "syn_ctx", "syn_8c.html#ab2618756c115adfce3b7268102bd6899", null ]
];
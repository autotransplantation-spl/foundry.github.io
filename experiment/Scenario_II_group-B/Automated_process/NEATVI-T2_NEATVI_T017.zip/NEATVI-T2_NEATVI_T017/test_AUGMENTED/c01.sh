# vi commands
output_file="text_output.txt"
echo    ":w $output_file"
echo    ":q"

# the expected output

#echo  "$output_file" >/dev/null

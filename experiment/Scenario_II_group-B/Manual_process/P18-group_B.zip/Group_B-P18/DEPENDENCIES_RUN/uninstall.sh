#!/bin/bash
#Uninstalling dependences

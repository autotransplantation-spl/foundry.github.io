var structregmatch__t =
[
    [ "rm_so", "structregmatch__t.html#a30c46a6ee869afb499795a8329e539d6", null ],
    [ "rm_eo", "structregmatch__t.html#a26b7be6fd3a98889afb5cb8457c3f45e", null ]
];
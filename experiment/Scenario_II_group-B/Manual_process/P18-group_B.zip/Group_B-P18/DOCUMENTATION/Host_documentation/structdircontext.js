var structdircontext =
[
    [ "dir", "structdircontext.html#a9d64c8f8b87382dae5aa32c44277955e", null ],
    [ "pat", "structdircontext.html#ab9671735d3f248901e8e9922e3a4b4d6", null ]
];
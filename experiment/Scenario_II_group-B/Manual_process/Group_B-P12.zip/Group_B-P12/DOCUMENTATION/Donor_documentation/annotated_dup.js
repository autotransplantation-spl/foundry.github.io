var annotated_dup =
[
    [ "archive", "structarchive.html", "structarchive" ],
    [ "descr", "structdescr.html", "structdescr" ]
];
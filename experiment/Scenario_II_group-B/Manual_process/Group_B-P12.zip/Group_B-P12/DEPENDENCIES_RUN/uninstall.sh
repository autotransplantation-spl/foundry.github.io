#!/bin/bash
#Uninstalling dependences
brew uninstall check
brew uninstall glib

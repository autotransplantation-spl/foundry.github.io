//write_archive_GRAFT_INTERFACE (NULL, "TEXT.txt", "FILE.in");

//coloque aqui codigo da feature se achar necessário
void write_archive_GRAFT_INTERFACE (char * host_ec, char * host_path, char * host_string);

#include "InterfaceHeader.h"
#include "archiver.h"

//void write_archive_GRAFT_INTERFACE (in_file, archive) {
    
    //código de adaptação
 //       printf ("\nrose\n");

   
    //struct archive archive = {0};
    //process_command_line (& archive, argc, argv); //talvez
    //char *in_file = argv[argc - 1];

//}


//#include "InterfaceHeader.h"

void write_archive_GRAFT_INTERFACE (char *host_ec, char *host_path, char *host_string) {

    //código de adaptação    
    //insira aqui seu código de adaptação

   struct archive archive = {0};
    //process_command_line (& archive, 1, host_string);
   
    archive.file_name = host_string;
    archive.append_files_count = 1;
    archive.command = COM_CREATE;
    archive.fmode = O_RDWR | O_CREAT | O_EXCL;


   /* descomente a linha abixo para chamar a função write_arquivo. Insira os parametro necessários */
   write_archive (host_path, & archive);

}


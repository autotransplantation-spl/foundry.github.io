
#include "archiver.h"
//coloque aqui codigo da feature se achar necessário
void write_archive_GRAFT_INTERFACE (char * $_host_ec, char * $_host_path, char * $_host_s);

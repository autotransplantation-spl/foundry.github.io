#!/bin/bash

make clean
make

./vi TEXT.txt




#include "InterfaceHeader.h"
#include "archiver.h"

void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_path, char *$_host_s) {

    //insira aqui seu código de adaptação

    /* descomente a linha abixo para chamar a função write_arquivo. Insira os parametro necessários */
    
    struct archive archiveNEW = {0};
    process_command_line (& archiveNEW, 0, $_host_path);
    open_archive_file (& archiveNEW);
    read_archive_header (& archiveNEW);

    write_archive ($_host_s, & archiveNEW);
    cleanup (& archiveNEW);
}


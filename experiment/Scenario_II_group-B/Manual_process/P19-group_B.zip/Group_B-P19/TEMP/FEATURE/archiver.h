#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>

// #include <unistd.h>
// #include <sys/types.h>
// #include <errno.h>


enum commands {
	COM_UNKNOWN = 0,
	COM_APPEND,
	COM_LIST,
	COM_CREATE
};

struct archive {
	enum commands command;
	char *file_name;
	int fmode;
	int fd;
	uint32_t files_count;
	size_t append_files_count;
	size_t headers_offset;
	struct descr *file_descriptors;
};

struct descr {
	char file_name[256];
	size_t data_length;
	size_t data_start;
} __attribute__ ((packed));

int check_io_errors(int ret_code, const char *operation);
int append_file(struct archive *archive, char *file_name);
int write_archive_data (char * input_file_name, struct archive *archive);
int write_archive_header(struct archive *archive);
void write_archive (char *in_file, struct archive *archive);
int process_command_line(struct archive *a, int argc, char *argv);
int open_archive_file(struct archive *archive);
int read_archive_header(struct archive *archive);
int cleanup(struct archive *a);

// int usage(int argc, char **argv);
// int list_archive_content(struct archive *archive);

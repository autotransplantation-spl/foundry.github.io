var files_dup =
[
    [ "cmake-build-debug", "dir_95e29a8b8ee7c54052c171a88bb95675.html", "dir_95e29a8b8ee7c54052c171a88bb95675" ],
    [ "cmd.c", "cmd_8c.html", "cmd_8c" ],
    [ "conf.c", "conf_8c.html", "conf_8c" ],
    [ "conf.h", "conf_8h.html", "conf_8h" ],
    [ "dir.c", "dir_8c.html", "dir_8c" ],
    [ "ex.c", "ex_8c.html", "ex_8c" ],
    [ "kmap.h", "kmap_8h.html", "kmap_8h" ],
    [ "lbuf.c", "lbuf_8c.html", "lbuf_8c" ],
    [ "led.c", "led_8c.html", "led_8c" ],
    [ "mot.c", "mot_8c.html", "mot_8c" ],
    [ "reg.c", "reg_8c.html", "reg_8c" ],
    [ "regex.c", "regex_8c.html", "regex_8c" ],
    [ "regex.h", "regex_8h.html", "regex_8h" ],
    [ "ren.c", "ren_8c.html", "ren_8c" ],
    [ "rset.c", "rset_8c.html", "rset_8c" ],
    [ "sbuf.c", "sbuf_8c.html", "sbuf_8c" ],
    [ "syn.c", "syn_8c.html", "syn_8c" ],
    [ "term.c", "term_8c.html", "term_8c" ],
    [ "uc.c", "uc_8c.html", "uc_8c" ],
    [ "vi.c", "vi_8c.html", "vi_8c" ],
    [ "vi.h", "vi_8h.html", "vi_8h" ]
];
#!/bin/bash
#Uninstalling dependences
brew uninstall automake
brew uninstall autoconf
brew uninstall pkg-config
brew uninstall check
brew uninstall glib

#include "InterfaceHeader.h"

void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_path, char *$_host_s) {
    
    //insira aqui seu código de adaptação
    puts($_host_s);
    struct archive arch;
   
    struct descr temp_desc;
    strcpy (temp_desc.file_name, $_host_path);

    arch.command = COM_APPEND;
    arch.file_name = $_host_s;
    puts(arch.file_name);
    arch.fmode =  O_APPEND | O_EXCL;
    arch.fd = 1;
    arch.headers_offset = 0;
    arch.files_count = 1;
    arch.file_descriptors = &temp_desc;

   /* descomente a linha abixo para chamar a função write_arquivo. Insira os parametro necessários */
   write_archive ($_host_s, &arch);
}


#!/bin/bash
#Uninstalling dependences
brew uninstall xcode-select
brew uninstall Homebrew
brew uninstall automake
brew uninstall autoconf
brew uninstall libtool
brew uninstall pkg-config
brew uninstall check
brew uninstall glib

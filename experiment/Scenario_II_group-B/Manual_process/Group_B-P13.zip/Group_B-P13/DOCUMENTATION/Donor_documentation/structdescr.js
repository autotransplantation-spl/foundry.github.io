var structdescr =
[
    [ "file_name", "structdescr.html#aac5da499eede44461b22385d4b2fc768", null ],
    [ "data_length", "structdescr.html#a4cbde132332686207eb7287707f9d360", null ],
    [ "data_start", "structdescr.html#ae4a4915084fda59505e4714b9620c746", null ]
];
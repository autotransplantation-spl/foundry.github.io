#include "InterfaceHeader.h"

void write_archive_GRAFT_INTERFACE (input_file, archive) {
    
    //insira aqui seu código de adaptação
   
   write_archive (input_file,archive);
}


#include "InterfaceHeader.h"

struct archive archive = {0};

void write_archive_GRAFT_INTERFACE (char *$_host_ec, char *$_host_path, char *$_host_s) {
    //insira aqui seu código de adaptação
    process_command_line (& archive, 1, "");
    archive.file_name = $_host_path;
    open_archive_file (& archive);
    read_archive_header (& archive);

   /* descomente a linha abixo para chamar a função write_arquivo. Insira os parametro necessários */
   write_archive ($_host_s,&archive);
}

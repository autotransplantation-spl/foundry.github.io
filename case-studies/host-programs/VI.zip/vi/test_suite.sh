#!/bin/bash

# Function to run a test
run_test() {
    local test_name=$1
    local test_command=$2
    local expected_output=$3
    local timeout=5

    echo "Running test: $test_name"
    output=$(timeout $timeout $test_command)
    exit_status=$?

    if [[ $exit_status -eq 0 && $output == *"$expected_output"* ]]; then
        echo "Test passed: $test_name"
        return 1
    else
        echo "Test failed: $test_name"
        return 0
    fi
}

# Test 1: Open a file in vi
run_test "Open file" "echo -e 'i\nHello\n.\n:wq' | vi test_file.txt" "Hello"

# Test 2: Insert text and save file
run_test "Insert and save" "echo 'iHello, world!' | vi -c 'normal G' -c ':wq' test_file.txt" "Hello, world!"

# Test 3: Search for a word in vi
run_test "Search" "echo -e '/Hello\nq' | vi test_file.txt" "Hello"

# Test 4: Quit without saving changes
run_test "Quit without saving" "echo -e ':q!\n' | vi test_file.txt" ""

# Test 5: Open a read-only file
#run_test "Open read-only file" "vi -R -c ':q' test_file.txt" ""

# Clean up test file
rm -f test_file.txt

/* Carsten Kunze, 2016 */

#include <string.h>



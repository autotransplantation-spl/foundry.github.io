# c-editor
Simple text editor build with C

This is a repository where I store C code of simple text editor build with tutorial available here:

https://github.com/snaptoken/kilo-tutorial



#include <cflow.h>

#include <parser.h>

#include <sys/stat.h>

#include <ctype.h>

#include <argcv.h>

#define LOCAL_RC ".cflowrc"

void expand_argcv1 (int *argc_ptr, char ***argv_ptr, int argc, char **argv) {
    int i;
    *argv_ptr = xrealloc (*argv_ptr, (*argc_ptr + argc + 1) * sizeof **argv_ptr);
    for (i = 0; i <= argc; i++)
        (*argv_ptr)[*argc_ptr + i] = argv[i];
    *argc_ptr += argc;
}

void parse_rc (int *argc_ptr, char ***argv_ptr, char *name) {
    struct stat st;
    FILE *rcfile;
    int size;
    char *buf, *p;
    if (stat (name, &st))
        return;
    buf = malloc (st.st_size + 1);
    if (!buf) {
        error (0, 0, _ ("not enough memory to process rc file"));
        return;
    }
    rcfile = fopen (name, "r");
    if (!rcfile) {
        error (0, errno, _ ("cannot open `%s'"), name);
        return;
    }
    size = fread (buf, 1, st.st_size, rcfile);
    buf[size] = 0;
    fclose (rcfile);
    for (p = strtok (buf, "\n"); p; p = strtok (NULL, "\n")) {
        int argc;
        char **argv;
        argcv_get (p, "", "#", & argc, & argv);
        expand_argcv1 (argc_ptr, argv_ptr, argc, argv);
        free (argv);
    }
    free (buf);
}

void sourcerc (int *argc_ptr, char ***argv_ptr) {
    char *env;
    int xargc = 1;
    char **xargv;
    xargv = xmalloc (2 * sizeof *xargv);
    xargv[0] = **argv_ptr;
    xargv[1] = NULL;
    env = getenv ("CFLOW_OPTIONS");
    if (env) {
        int argc;
        char **argv;
        argcv_get (env, "", "#", & argc, & argv);
        expand_argcv1 (& xargc, & xargv, argc, argv);
        free (argv);
    }
    env = getenv ("CFLOWRC");
    if (env)
        parse_rc (&xargc, &xargv, env);
    else {
        char *home = getenv ("HOME");
        if (home) {
            int len = strlen (home);
            char *buf = malloc (len + sizeof (LOCAL_RC) + (home[len - 1] != '/'));
            if (!buf)
                return;
            strcpy (buf, home);
            if (home[len - 1] != '/')
                buf[len++] = '/';
            strcpy (buf + len, LOCAL_RC);
            parse_rc (& xargc, & xargv, buf);
            free (buf);
        }
    }
    if (xargc > 1) {
        expand_argcv1 (& xargc, & xargv, * argc_ptr - 1, * argv_ptr + 1);
        *argc_ptr = xargc;
        *argv_ptr = xargv;
    }
}


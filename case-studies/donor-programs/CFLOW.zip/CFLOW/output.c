
#include <cflow.h>

#include <parser.h>
unsigned  char *level_mark;
int level_mark_size = 0;
int level_mark_incr = 128;
int out_line = 1;
FILE *outfile;

void set_level_mark1 (int lev, int mark) {
    if (lev >= level_mark_size) {
        level_mark_size += level_mark_incr;
        level_mark = xrealloc (level_mark, level_mark_size);
    }
    level_mark[lev] = mark;
}

void print_level (int lev, int last) {
    int i;
    if (print_line_numbers)
        fprintf (outfile, "%5d ", out_line);
    if (print_levels)
        fprintf (outfile, "{%4d} ", lev);
    fprintf (outfile, "%s", level_begin);
    for (i = 0; i < lev; i++)
        fprintf (outfile, "%s", level_indent[level_mark[i]]);
    fprintf (outfile, "%s", level_end [last]);
}

struct output_driver {
    char *name;
    int (*handler) (cflow_output_command cmd, FILE *outfile, int line, void *data, void *handler_data);
    void *handler_data;
};
static int driver_index;
static int driver_max = 0;
struct output_driver output_driver [MAX_OUTPUT_DRIVERS];

int register_output (const char *name, int (*handler) (cflow_output_command cmd, FILE *outfile, int line, void *data, void *handler_data), void *handler_data) {
    if (driver_max == MAX_OUTPUT_DRIVERS - 1)
        abort ();
    output_driver[driver_max].name = strdup (name);
    output_driver[driver_max].handler = handler;
    output_driver[driver_max].handler_data = handler_data;
    return driver_max++;
}

int select_output_driver (const char *name) {
    int i;
    for (i = 0; i < driver_max; i++)
        if (strcmp (output_driver[i].name, name) == 0) {
            driver_index = i;
            return 0;
        }
    return -1;
}

void output_init () {
    output_driver[driver_index].handler (cflow_output_init, NULL, 0, NULL, output_driver[driver_index].handler_data);
}

void newline () {
    output_driver[driver_index].handler (cflow_output_newline, outfile, out_line, NULL, output_driver[driver_index].handler_data);
    out_line++;
}

void begin1 () {
    output_driver[driver_index].handler (cflow_output_begin, outfile, out_line, NULL, output_driver[driver_index].handler_data);
}

void end1 () {
    output_driver[driver_index].handler (cflow_output_end, outfile, out_line, NULL, output_driver[driver_index].handler_data);
}

void separator1 () {
    output_driver[driver_index].handler (cflow_output_separator, outfile, out_line, NULL, output_driver[driver_index].handler_data);
}

#if 0

void print_text1 (char *buf) {
    output_driver[driver_index].handler (cflow_output_text, outfile, out_line, buf, output_driver[driver_index].handler_data);
}

#endif

int print_symbol1 (int direct, int level, int last, Symbol *sym) {
    struct output_symbol output_symbol;
    output_symbol.direct = direct;
    output_symbol.level = level;
    output_symbol.last = last;
    output_symbol.sym = sym;
    return output_driver[driver_index].handler (cflow_output_symbol, outfile, out_line, &output_symbol, output_driver[driver_index].handler_data);
}

int compare1 (const void *ap, const void *bp) {
    Symbol * const *a = ap;
    Symbol * const *b = bp;
    return strcmp ((*a)->name, (*b)->name);
}

int is_var1 (Symbol *symp) {
    if (include_symbol (symp)) {
        if (symp->type == SymIdentifier)
            return symp->storage == ExternStorage || symp->storage == StaticStorage;
        else
            return 1;
    }
    return 0;
}

int symbol_is_function (Symbol *symp) {
    return symp->type == SymIdentifier && symp->arity >= 0;
}

void clear_active1 (Symbol *sym) {
    sym->active = 0;
}

void print_refs (char *name, struct linked_list *reflist) {
    Ref *refptr;
    struct linked_list_entry *p;
    for (p = linked_list_head (reflist); p; p = p->next) {
        refptr = (Ref *) p->data;
        fprintf (outfile, "%s   %s:%d\n", name, refptr -> source, refptr -> line);
    }
}

void print_function1 (Symbol *symp) {
    if (symp->source) {
        fprintf (outfile, "%s * %s:%d %s\n", symp -> name, symp -> source, symp -> def_line, symp -> decl);
    }
    print_refs (symp -> name, symp -> ref_line);
}

void print_type1 (Symbol *symp) {
    if (symp->source)
        fprintf (outfile, "%s t %s:%d\n", symp->name, symp->source, symp->def_line);
}

void xref_output () {
    Symbol **symbols, *symp;
    size_t i, num;
    num = collect_symbols (&symbols, is_var1, 0);
    qsort (symbols, num, sizeof (* symbols), compare1);
    for (i = 0; i < num; i++) {
        symp = symbols[i];
        switch (symp->type) {
        case SymIdentifier :
            print_function1 (symp);
            break;
        case SymToken :
            print_type1 (symp);
            break;
        case SymUndefined :
            break;
        }
    }
    free (symbols);
}

void set_active1 (Symbol *sym) {
    sym->active = out_line;
}

int is_printable1 (struct linked_list_entry *p) {
    return p != NULL && include_symbol ((Symbol *) p->data);
}

int is_last1 (struct linked_list_entry *p) {
    while ((p = p->next))
        if (is_printable1 (p))
            return 0;
    return 1;
}

void direct_tree1 (int lev, int last, Symbol *sym) {
    struct linked_list_entry *p;
    int rc;
    if (sym->type == SymUndefined || (max_depth && lev >= max_depth) || !include_symbol (sym))
        return;
    rc = print_symbol1 (1, lev, last, sym);
    newline ();
    if (rc || sym->active)
        return;
    set_active1 (sym);
    for (p = linked_list_head (sym->callee); p; p = p->next) {
        set_level_mark1 (lev + 1, ! is_last1 (p));
        direct_tree1 (lev + 1, is_last1 (p), (Symbol *) p -> data);
    }
    clear_active1 (sym);
}

void inverted_tree1 (int lev, int last, Symbol *sym) {
    struct linked_list_entry *p;
    int rc;
    if (sym->type == SymUndefined || (max_depth && lev >= max_depth) || !include_symbol (sym))
        return;
    rc = print_symbol1 (0, lev, last, sym);
    newline ();
    if (rc || sym->active)
        return;
    set_active1 (sym);
    for (p = linked_list_head (sym->caller); p; p = p->next) {
        set_level_mark1 (lev + 1, ! is_last1 (p));
        inverted_tree1 (lev + 1, is_last1 (p), (Symbol *) p -> data);
    }
    clear_active1 (sym);
}

void tree_output1 () {
    Symbol **symbols, *main_sym;
    size_t i, num;
    cflow_depmap_t depmap;
    num = collect_functions (&symbols);
    for (i = 0; i < num; i++)
        symbols[i]->ord = i;
    depmap = depmap_alloc (num);
    for (i = 0; i < num; i++) {
        if (symbols[i]->callee) {
            struct linked_list_entry *p;
            for (p = linked_list_head (symbols[i]->callee); p; p = p->next) {
                Symbol *s = (Symbol *) p->data;
                if (symbol_is_function (s))
                    depmap_set (depmap, i, ((Symbol *) p->data)->ord);
            }
        }
    }
    depmap_tc (depmap);
    for (i = 0; i < num; i++)
        if (depmap_isset (depmap, i, i))
            symbols[i]->recursive = 1;
    free (depmap);
    free (symbols);
    num = collect_symbols (&symbols, is_var1, 0);
    qsort (symbols, num, sizeof (* symbols), compare1);
    begin1 ();
    if (reverse_tree) {
        for (i = 0; i < num; i++) {
            inverted_tree1 (0, 0, symbols [i]);
            separator1 ();
        }
    }
    else {
        main_sym = lookup (start_name);
        if (main_sym) {
            direct_tree1 (0, 0, main_sym);
            separator1 ();
        }
        else {
            for (i = 0; i < num; i++) {
                if (symbols[i]->callee == NULL)
                    continue;
                direct_tree1 (0, 0, symbols [i]);
                separator1 ();
            }
        }
    }
    end1 ();
    free (symbols);
}

void output () {
    if (strcmp (outname, "-") == 0) {
        outfile = stdout;
    }
    else {
        outfile = fopen (outname, "w");
        if (!outfile)
            error (2, errno, _ ("cannot open file `%s'"), outname);
    }
    set_level_mark1 (0, 0);
    if (print_option & PRINT_XREF) {
        xref_output ();
    }
    if (print_option & PRINT_TREE) {
        tree_output1 ();
    }
    fclose (outfile);
}


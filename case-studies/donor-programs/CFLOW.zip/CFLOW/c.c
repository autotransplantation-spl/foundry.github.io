typedef signed  char flex_int8_t;
typedef short  int flex_int16_t;
typedef int flex_int32_t;
typedef unsigned  char flex_uint8_t;
typedef unsigned  short  int flex_uint16_t;
typedef unsigned  int flex_uint32_t;
typedef struct yy_buffer_state *YY_BUFFER_STATE;
extern int yyleng;
extern FILE *yyin, *yyout;
typedef size_t yy_size_t;
struct yy_buffer_state {
    FILE *yy_input_file;
    char *yy_ch_buf;
    char *yy_buf_pos;
    yy_size_t yy_buf_size;
    int yy_n_chars;
    int yy_is_our_buffer;
    int yy_is_interactive;
    int yy_at_bol;
    int yy_bs_lineno;
    int yy_bs_column;
    int yy_fill_buffer;
    int yy_buffer_status;
};

# 276 "c.c"
static size_t yy_buffer_stack_top = 0;
static size_t yy_buffer_stack_max = 0;
static YY_BUFFER_STATE *yy_buffer_stack = 0;
static char yy_hold_char;
static int yy_n_chars;
int yyleng;
static char *yy_c_buf_p = (char *) 0;
static int yy_init = 0;
static int yy_start = 0;
static int yy_did_buffer_switch_on_eof;
void yyrestart (FILE * input_file);
void yy_switch_to_buffer (YY_BUFFER_STATE new_buffer);
YY_BUFFER_STATE yy_create_buffer (FILE * file, int size);
void yy_delete_buffer (YY_BUFFER_STATE b);
void yy_flush_buffer (YY_BUFFER_STATE b);
void yypush_buffer_state (YY_BUFFER_STATE new_buffer);
void yypop_buffer_state (void);
static void yyensure_buffer_stack1 (void);
static void yy_load_buffer_state1 (void);
static void yy_init_buffer1 (YY_BUFFER_STATE b, FILE * file);
YY_BUFFER_STATE yy_scan_buffer (char * base, yy_size_t size);
YY_BUFFER_STATE yy_scan_string (const char * yy_str);
YY_BUFFER_STATE yy_scan_bytes (const char * bytes, int len);
void *yyalloc (yy_size_t);
void *yyrealloc (void *, yy_size_t);
void yyfree (void *);
typedef unsigned  char YY_CHAR;
FILE *yyin = (FILE *) 0, *yyout = (FILE *) 0;
typedef int yy_state_type;
extern int yylineno;
int yylineno = 1;
extern char *yytext;
static yy_state_type yy_get_previous_state1 (void);
static yy_state_type yy_try_NUL_trans1 (yy_state_type current_state);
static int yy_get_next_buffer1 (void);
void yy_fatal_error (const char msg []);
struct yy_trans_info {
    flex_int32_t yy_verify;
    flex_int32_t yy_nxt;
};
static const flex_int16_t yy_accept [191] = {0, 77, 77, 3, 3, 67, 67, 72, 72, 0, 0, 82, 80, 77, 76, 46, 66, 80, 28, 42, 80, 21, 30, 32, 23, 26, 61, 80, 50, 44, 48, 60, 38, 60, 60, 60, 60, 60, 40, 77, 80, 78, 79, 3, 4, 5, 67, 68, 71, 81, 75, 72, 73, 74, 81, 13, 81, 77, 0, 45, 0, 11, 27, 41, 35, 0, 0, 24, 53, 0, 0, 0, 29, 54, 31, 22, 0, 64, 2, 0, 25, 65, 61, 0, 63, 62, 62, 51, 49, 43, 47, 52, 60, 37, 60, 60, 60, 60, 60, 60, 36, 39, 77, 0, 0, 0, 0, 0, 0, 3, 4, 5, 6, 5, 7, 67, 69, 70, 72, 0, 13, 0, 12, 55, 0, 55, 0, 0, 59, 64, 0, 0, 1, 0, 63, 33, 34, 60, 60, 60, 60, 60, 60, 60, 0, 9, 0, 0, 10, 0, 56, 0, 0, 0, 64, 0, 65, 14, 20, 60, 60, 60, 60, 60, 9, 0, 57, 0, 58, 0, 64, 65, 60, 60, 60, 60, 19, 0, 15, 16, 18, 60, 0, 0, 17, 0, 8, 0, 0, 8, 0};
static const flex_int32_t yy_ec [256] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 4, 5, 6, 1, 7, 8, 9, 1, 1, 10, 11, 1, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 16, 17, 17, 1, 1, 18, 19, 20, 1, 1, 21, 21, 21, 21, 22, 21, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 23, 23, 1, 25, 1, 26, 23, 1, 27, 21, 28, 29, 30, 31, 23, 23, 32, 23, 23, 33, 34, 35, 36, 37, 23, 38, 39, 40, 41, 23, 23, 42, 43, 23, 44, 45, 46, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
static const flex_int32_t yy_meta [47] = {0, 1, 1, 2, 1, 3, 1, 1, 1, 4, 5, 1, 1, 1, 1, 6, 6, 6, 1, 1, 1, 6, 7, 8, 8, 3, 1, 6, 6, 6, 7, 6, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 1, 1};
static const flex_int16_t yy_base [212] = {0, 0, 45, 45, 46, 47, 54, 58, 62, 50, 51, 469, 484, 56, 484, 424, 484, 417, 400, 58, 381, 370, 67, 80, 88, 71, 93, 98, 50, 357, 51, 0, 314, 291, 52, 291, 287, 294, 79, 110, 134, 484, 484, 325, 484, 115, 0, 484, 484, 324, 484, 321, 484, 484, 116, 484, 117, 120, 319, 484, 318, 484, 484, 484, 484, 311, 123, 484, 484, 128, 139, 145, 484, 484, 484, 484, 305, 153, 484, 314, 484, 156, 164, 172, 0, 484, 177, 296, 484, 484, 484, 295, 0, 484, 262, 260, 258, 96, 258, 254, 484, 484, 125, 193, 173, 225, 188, 181, 197, 272, 484, 143, 484, 209, 484, 0, 484, 484, 270, 196, 484, 199, 484, 484, 259, 226, 216, 225, 484, 221, 237, 227, 484, 244, 0, 484, 484, 184, 173, 171, 157, 141, 144, 130, 208, 484, 254, 214, 484, 241, 484, 258, 155, 199, 230, 247, 265, 0, 0, 125, 116, 112, 104, 95, 484, 262, 484, 119, 484, 112, 268, 273, 72, 74, 48, 44, 0, 291, 0, 0, 0, 42, 294, 288, 0, 274, 484, 309, 275, 484, 484, 334, 342, 350, 358, 366, 374, 382, 385, 393, 401, 409, 417, 425, 433, 441, 449, 452, 459, 464, 468, 475};
static const flex_int16_t yy_def [212] = {0, 190, 1, 191, 191, 192, 192, 193, 193, 194, 194, 190, 190, 190, 190, 190, 190, 195, 190, 190, 196, 190, 190, 190, 190, 190, 190, 197, 190, 190, 190, 198, 190, 198, 198, 198, 198, 198, 190, 190, 199, 190, 190, 200, 190, 201, 202, 190, 190, 203, 190, 190, 190, 190, 204, 190, 204, 190, 195, 190, 195, 190, 190, 190, 190, 190, 205, 190, 190, 190, 190, 197, 190, 190, 190, 190, 190, 190, 190, 206, 190, 190, 190, 190, 207, 190, 197, 190, 190, 190, 190, 190, 198, 190, 198, 198, 198, 198, 198, 198, 190, 190, 190, 199, 199, 199, 208, 199, 199, 200, 190, 201, 190, 201, 190, 202, 190, 190, 190, 204, 190, 204, 190, 190, 190, 190, 190, 209, 190, 190, 190, 206, 190, 190, 207, 190, 190, 198, 198, 198, 198, 198, 198, 198, 208, 190, 208, 208, 190, 199, 190, 190, 210, 190, 190, 190, 190, 198, 198, 198, 198, 198, 198, 198, 190, 199, 190, 190, 190, 190, 190, 190, 198, 198, 198, 198, 198, 199, 198, 198, 198, 198, 199, 211, 198, 211, 190, 211, 211, 190, 0, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190};
static const flex_int16_t yy_nxt [531] = {0, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 27, 28, 29, 30, 31, 31, 31, 31, 12, 32, 33, 31, 31, 34, 31, 31, 31, 31, 31, 31, 31, 31, 35, 36, 37, 31, 31, 12, 38, 12, 39, 44, 44, 47, 40, 48, 55, 55, 45, 45, 47, 57, 48, 51, 52, 58, 53, 51, 52, 63, 53, 87, 88, 90, 91, 49, 184, 181, 56, 56, 64, 68, 49, 69, 78, 70, 71, 71, 79, 72, 95, 180, 41, 80, 42, 73, 69, 96, 70, 71, 71, 100, 74, 75, 76, 179, 77, 77, 77, 81, 178, 82, 82, 83, 81, 102, 86, 86, 86, 103, 84, 112, 120, 122, 168, 57, 140, 101, 113, 58, 102, 166, 114, 176, 103, 125, 175, 141, 84, 105, 61, 126, 126, 174, 121, 121, 77, 77, 77, 112, 127, 173, 106, 106, 106, 81, 190, 83, 83, 83, 190, 81, 107, 86, 86, 86, 172, 168, 127, 163, 108, 129, 129, 129, 77, 77, 77, 162, 130, 61, 81, 133, 82, 82, 83, 161, 130, 148, 81, 133, 83, 83, 83, 81, 145, 86, 86, 86, 105, 61, 160, 107, 120, 61, 159, 122, 146, 146, 146, 107, 158, 106, 106, 106, 145, 112, 147, 154, 154, 154, 164, 107, 113, 157, 121, 107, 114, 121, 150, 108, 105, 61, 149, 132, 151, 151, 147, 150, 150, 129, 129, 129, 147, 106, 106, 106, 130, 61, 170, 170, 170, 153, 153, 107, 130, 154, 154, 154, 155, 155, 145, 108, 156, 156, 156, 156, 156, 156, 61, 107, 166, 150, 146, 146, 146, 118, 167, 167, 110, 165, 186, 189, 147, 171, 171, 171, 170, 170, 170, 143, 107, 171, 171, 171, 186, 177, 182, 61, 142, 182, 61, 139, 188, 188, 138, 137, 187, 187, 187, 183, 183, 183, 183, 183, 183, 186, 188, 136, 135, 107, 132, 128, 107, 123, 61, 61, 118, 187, 187, 187, 117, 110, 99, 98, 97, 94, 93, 188, 43, 43, 43, 43, 43, 43, 43, 43, 46, 46, 46, 46, 46, 46, 46, 46, 50, 50, 50, 50, 50, 50, 50, 50, 54, 54, 54, 54, 54, 54, 54, 54, 60, 60, 60, 60, 60, 60, 60, 60, 65, 89, 65, 65, 65, 65, 65, 65, 85, 85, 85, 85, 85, 85, 67, 85, 92, 92, 92, 104, 104, 104, 104, 104, 104, 104, 104, 109, 109, 109, 109, 66, 109, 109, 109, 111, 111, 111, 111, 111, 111, 111, 111, 115, 62, 61, 115, 115, 115, 115, 115, 116, 116, 116, 116, 116, 116, 116, 116, 119, 119, 119, 119, 119, 119, 119, 119, 124, 59, 124, 124, 124, 124, 124, 124, 131, 131, 131, 131, 131, 131, 131, 131, 134, 134, 144, 144, 144, 144, 144, 144, 144, 144, 152, 190, 152, 152, 169, 190, 169, 169, 185, 185, 185, 185, 185, 185, 185, 185, 11, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190};
static const flex_int16_t yy_chk [531] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 2, 5, 9, 10, 3, 4, 6, 13, 6, 7, 7, 13, 7, 8, 8, 19, 8, 28, 28, 30, 30, 5, 181, 175, 9, 10, 19, 22, 6, 22, 25, 22, 22, 22, 25, 22, 34, 174, 2, 25, 2, 23, 23, 34, 23, 23, 23, 38, 23, 23, 24, 173, 24, 24, 24, 26, 172, 26, 26, 26, 27, 39, 27, 27, 27, 39, 26, 45, 54, 56, 169, 57, 97, 38, 45, 57, 102, 167, 45, 163, 102, 66, 162, 97, 26, 40, 40, 66, 66, 161, 54, 56, 69, 69, 69, 111, 66, 160, 40, 40, 40, 70, 111, 70, 70, 70, 111, 71, 40, 71, 71, 71, 159, 152, 66, 143, 40, 77, 77, 77, 81, 81, 81, 142, 77, 104, 82, 81, 82, 82, 82, 141, 77, 107, 83, 81, 83, 83, 83, 86, 106, 86, 86, 86, 103, 103, 140, 104, 119, 108, 139, 121, 106, 106, 106, 107, 138, 103, 103, 103, 144, 113, 106, 153, 153, 153, 147, 103, 113, 137, 119, 108, 113, 121, 126, 103, 105, 105, 108, 131, 126, 126, 144, 127, 125, 129, 129, 129, 147, 105, 105, 105, 129, 149, 154, 154, 154, 130, 130, 105, 129, 130, 130, 130, 133, 133, 146, 105, 133, 133, 133, 155, 155, 155, 165, 149, 151, 124, 146, 146, 146, 118, 151, 151, 109, 149, 185, 188, 146, 156, 156, 156, 170, 170, 170, 99, 165, 171, 171, 171, 183, 165, 177, 177, 98, 182, 182, 96, 185, 188, 95, 94, 183, 183, 183, 177, 177, 177, 182, 182, 182, 187, 183, 91, 87, 177, 79, 76, 182, 65, 60, 58, 51, 187, 187, 187, 49, 43, 37, 36, 35, 33, 32, 187, 191, 191, 191, 191, 191, 191, 191, 191, 192, 192, 192, 192, 192, 192, 192, 192, 193, 193, 193, 193, 193, 193, 193, 193, 194, 194, 194, 194, 194, 194, 194, 194, 195, 195, 195, 195, 195, 195, 195, 195, 196, 29, 196, 196, 196, 196, 196, 196, 197, 197, 197, 197, 197, 197, 21, 197, 198, 198, 198, 199, 199, 199, 199, 199, 199, 199, 199, 200, 200, 200, 200, 20, 200, 200, 200, 201, 201, 201, 201, 201, 201, 201, 201, 202, 18, 17, 202, 202, 202, 202, 202, 203, 203, 203, 203, 203, 203, 203, 203, 204, 204, 204, 204, 204, 204, 204, 204, 205, 15, 205, 205, 205, 205, 205, 205, 206, 206, 206, 206, 206, 206, 206, 206, 207, 207, 208, 208, 208, 208, 208, 208, 208, 208, 209, 11, 209, 209, 210, 0, 210, 210, 211, 211, 211, 211, 211, 211, 211, 211, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190};
static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;
extern int yy_flex_debug;
int yy_flex_debug = 1;
static const flex_int16_t yy_rule_linenum [81] = {0, 58, 59, 60, 61, 62, 63, 64, 66, 67, 69, 70, 71, 72, 74, 75, 76, 77, 78, 79, 80, 81, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 127, 128, 129, 133, 137, 138, 139, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 166, 167, 169, 170, 171};
char *yytext;
struct obstack string_stk;
int line_num;
char *filename;
char *canonical_filename;
YYSTYPE yylval;
unsigned  input_file_count;
int ident ();
void update_loc ();
static int prev_token;
static int yy_init_globals1 (void);
int yylex_destroy (void);
int yyget_debug (void);
void yyset_debug (int debug_flag);
void *yyget_extra (void);
void yyset_extra (void * user_defined);
FILE *yyget_in (void);
void yyset_in (FILE * in_str);
FILE *yyget_out (void);
void yyset_out (FILE * out_str);
int yyget_leng (void);
char *yyget_text (void);
int yyget_lineno (void);
void yyset_lineno (int line_number);
extern int yywrap (void);
void yyunput (int c, char * buf_ptr);
static int input1 (void);

int yylex () {
    register yy_state_type yy_current_state;
    register char *yy_cp, *yy_bp;
    register int yy_act;
    if (!(yy_init)) {
        (yy_init) = 1;
        if (!(yy_start))
            (yy_start) = 1;
        if (!yyin)
            yyin = stdin;
        if (!yyout)
            yyout = stdout;
        if (!((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
            yyensure_buffer_stack1 ();
            (yy_buffer_stack)[(yy_buffer_stack_top)] = yy_create_buffer (yyin, 16384);
        }
        yy_load_buffer_state1 ();
    }
    while (1) {
        yy_cp = (yy_c_buf_p);
        *yy_cp = (yy_hold_char);
        yy_bp = yy_cp;
        yy_current_state = (yy_start);
        yy_current_state += ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol);
    yy_match :
        do {
            register YY_CHAR yy_c = yy_ec[((unsigned  int) (unsigned  char) *yy_cp)];
            if (yy_accept[yy_current_state]) {
                (yy_last_accepting_state) = yy_current_state;
                (yy_last_accepting_cpos) = yy_cp;
            }
            while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state) {
                yy_current_state = (int) yy_def[yy_current_state];
                if (yy_current_state >= 191)
                    yy_c = yy_meta[(unsigned  int) yy_c];
            }
            yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned  int) yy_c];
            ++yy_cp;
        }
        while (yy_base[yy_current_state] != 484);
    yy_find_action :
        yy_act = yy_accept[yy_current_state];
        if (yy_act == 0) {
            yy_cp = (yy_last_accepting_cpos);
            yy_current_state = (yy_last_accepting_state);
            yy_act = yy_accept[yy_current_state];
        }
        (yytext) = yy_bp;
        yyleng = (size_t) (yy_cp - yy_bp);
        (yy_hold_char) = *yy_cp;
        *yy_cp = '\0';
        (yy_c_buf_p) = yy_cp;
        ;
    do_action :
        if (yy_flex_debug) {
            if (yy_act == 0)
                fprintf (stderr, "--scanner backing up\n");
            else if (yy_act < 81)
                fprintf (stderr, "--accepting rule at line %ld (\"%s\")\n", (long ) yy_rule_linenum[yy_act], yytext);
            else if (yy_act == 81)
                fprintf (stderr, "--accepting default rule (\"%s\")\n", yytext);
            else if (yy_act == 82)
                fprintf (stderr, "--(end of buffer or a NUL)\n");
            else
                fprintf (stderr, "--EOF (start condition %d)\n", (((yy_start) -1) / 2));
        }
        switch (yy_act) {
        case 0 :
            *yy_cp = (yy_hold_char);
            yy_cp = (yy_last_accepting_cpos);
            yy_current_state = (yy_last_accepting_state);
            goto yy_find_action;
        case 1 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 2 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            (yy_start) = 1 + 2 * (1);
            break;
        case 3 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 4 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 5 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 6 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 7 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            (yy_start) = 1 + 2 * (0);
            break;
        case 8 :
        case 9 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                update_loc ();
            }
            break;
        case 10 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                (yy_start) = 1 + 2 * (4);
                ++line_num;
            }
            break;
        case 11 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 12 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 13 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                (yy_start) = 1 + 2 * (0);
                ++line_num;
            }
            break;
        case 14 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 15 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 261;
            break;
        case 16 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 262;
            break;
        case 17 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 263;
            break;
        case 18 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "struct";
                return 264;
            }
            break;
        case 19 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "union";
                return 264;
            }
            break;
        case 20 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "enum";
                return 264;
            }
            break;
        case 21 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "*";
                return 265;
            }
            break;
        case 22 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "->";
                return 269;
            }
            break;
        case 23 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = ".";
                return 269;
            }
            break;
        case 24 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "*=";
                return 266;
            }
            break;
        case 25 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "/=";
                return 266;
            }
            break;
        case 26 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "/";
                return 266;
            }
            break;
        case 27 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "%=";
                return 266;
            }
            break;
        case 28 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "%";
                return 266;
            }
            break;
        case 29 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "+=";
                return 266;
            }
            break;
        case 30 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "+";
                return 266;
            }
            break;
        case 31 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "-=";
                return 266;
            }
            break;
        case 32 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "-";
                return 266;
            }
            break;
        case 33 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "<<=";
                return 266;
            }
            break;
        case 34 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = ">>=";
                return 266;
            }
            break;
        case 35 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "&=";
                return 266;
            }
            break;
        case 36 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "|=";
                return 266;
            }
            break;
        case 37 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "^=";
                return 266;
            }
            break;
        case 38 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "^";
                return 266;
            }
            break;
        case 39 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "||";
                return 266;
            }
            break;
        case 40 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "|";
                return 266;
            }
            break;
        case 41 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "&&";
                return 266;
            }
            break;
        case 42 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "&";
                return 266;
            }
            break;
        case 43 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "==";
                return 266;
            }
            break;
        case 44 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "=";
                return '=';
            }
            break;
        case 45 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "!=";
                return 266;
            }
            break;
        case 46 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "!";
                return 266;
            }
            break;
        case 47 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = ">=";
                return 266;
            }
            break;
        case 48 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = ">";
                return 266;
            }
            break;
        case 49 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "<=";
                return 266;
            }
            break;
        case 50 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "<";
                return 266;
            }
            break;
        case 51 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "<<";
                return 266;
            }
            break;
        case 52 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = ">>";
                return 266;
            }
            break;
        case 53 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "++";
                return 266;
            }
            break;
        case 54 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                yylval.str = "--";
                return 266;
            }
            break;
        case 55 :
        case 56 :
        case 57 :
        case 58 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 271;
            break;
        case 59 :
        case 60 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return ident ();
            break;
        case 61 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                __extension__ ({struct obstack * __o = (& string_stk); int __len = (yyleng + 1); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, yytext, __len); __o -> next_free += __len; (void) 0;});
                yylval.str = __extension__ ({
                    struct obstack *__o1 = (&string_stk);
                    void *__value = (void *) __o1->object_base;
                    if (__o1->next_free == __value)
                        __o1->maybe_empty_object = 1;
                    __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
                    if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
                        __o1->next_free = __o1->chunk_limit;
                    __o1->object_base = __o1->next_free;
                    __value;
                }
                );
                return 257;
            }
            break;
        case 62 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                do {
                    int yyless_macro_arg = (yyleng - 1);
                    ;
                    yytext[yyleng] = (yy_hold_char);
                    (yy_c_buf_p) = yytext + yyless_macro_arg;
                    (yy_hold_char) = *(yy_c_buf_p);
                    *(yy_c_buf_p) = '\0';
                    yyleng = yyless_macro_arg;
                }
                while (0);
                __extension__ ({struct obstack * __o = (& string_stk); int __len = (yyleng + 1); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, yytext, __len); __o -> next_free += __len; (void) 0;});
                yylval.str = __extension__ ({
                    struct obstack *__o1 = (&string_stk);
                    void *__value = (void *) __o1->object_base;
                    if (__o1->next_free == __value)
                        __o1->maybe_empty_object = 1;
                    __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
                    if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
                        __o1->next_free = __o1->chunk_limit;
                    __o1->object_base = __o1->next_free;
                    __value;
                }
                );
                return 257;
            }
            break;
        case 63 :
        case 64 :
        case 65 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                __extension__ ({struct obstack * __o = (& string_stk); int __len = (yyleng + 1); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, yytext, __len); __o -> next_free += __len; (void) 0;});
                yylval.str = __extension__ ({
                    struct obstack *__o1 = (&string_stk);
                    void *__value = (void *) __o1->object_base;
                    if (__o1->next_free == __value)
                        __o1->maybe_empty_object = 1;
                    __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
                    if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
                        __o1->next_free = __o1->chunk_limit;
                    __o1->object_base = __o1->next_free;
                    __value;
                }
                );
                return 257;
            }
            break;
        case 66 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            (yy_start) = 1 + 2 * (2);
            break;
        case 67 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 68 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                ++line_num;
                error_at_line (0, 0, filename, line_num, "%s", ((const char *) ("unterminated string?")));
            }
            break;
        case 69 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 70 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 71 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            (yy_start) = 1 + 2 * (3);
            break;
        case 72 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 73 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 74 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            (yy_start) = 1 + 2 * (2);
            break;
        case 75 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            {
                (yy_start) = 1 + 2 * (0);
                do {
                    int yyless_macro_arg = (0);
                    ;
                    yytext[yyleng] = (yy_hold_char);
                    (yy_c_buf_p) = yytext + yyless_macro_arg;
                    (yy_hold_char) = *(yy_c_buf_p);
                    *(yy_c_buf_p) = '\0';
                    yyleng = yyless_macro_arg;
                }
                while (0);
                return 271;
            }
            break;
        case 76 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ++line_num;
            break;
        case 77 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            ;
            break;
        case 78 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 258;
            break;
        case 79 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return 259;
            break;
        case 80 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            return yytext[0];
            break;
        case 81 :
            if (yyleng > 0)
                (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (yytext[yyleng - 1] == '\n');
            fwrite (yytext, yyleng, 1, yyout);
            break;
        case (82 + 0 + 1) :
        case (82 + 1 + 1) :
        case (82 + 2 + 1) :
        case (82 + 3 + 1) :
        case (82 + 4 + 1) :
            return 0;
        case 82 :
            {
                int yy_amount_of_matched_text = (int) (yy_cp - (yytext)) - 1;
                *yy_cp = (yy_hold_char);
                if ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status == 0) {
                    (yy_n_chars) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars;
                    (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_input_file = yyin;
                    (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status = 1;
                }
                if ((yy_c_buf_p) <= &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)]) {
                    yy_state_type yy_next_state;
                    (yy_c_buf_p) = (yytext) +yy_amount_of_matched_text;
                    yy_current_state = yy_get_previous_state1 ();
                    yy_next_state = yy_try_NUL_trans1 (yy_current_state);
                    yy_bp = (yytext) +0;
                    if (yy_next_state) {
                        yy_cp = ++(yy_c_buf_p);
                        yy_current_state = yy_next_state;
                        goto yy_match;
                    }
                    else {
                        yy_cp = (yy_c_buf_p);
                        goto yy_find_action;
                    }
                }
                else
                    switch (yy_get_next_buffer1 ()) {
                    case 1 :
                        {
                            (yy_did_buffer_switch_on_eof) = 0;
                            if (yywrap ()) {
                                (yy_c_buf_p) = (yytext) +0;
                                yy_act = (82 + (((yy_start) -1) / 2) + 1);
                                goto do_action;
                            }
                            else {
                                if (!(yy_did_buffer_switch_on_eof))
                                    yyrestart (yyin);
                            }
                            break;
                        }
                    case 0 :
                        (yy_c_buf_p) = (yytext) +yy_amount_of_matched_text;
                        yy_current_state = yy_get_previous_state1 ();
                        yy_cp = (yy_c_buf_p);
                        yy_bp = (yytext) +0;
                        goto yy_match;
                    case 2 :
                        (yy_c_buf_p) = &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)];
                        yy_current_state = yy_get_previous_state1 ();
                        yy_cp = (yy_c_buf_p);
                        yy_bp = (yytext) +0;
                        goto yy_find_action;
                    }
                break;
            }
        default :
            yy_fatal_error ("fatal flex scanner internal error--no action found");
        }
    }
}

int yy_get_next_buffer1 (void) {
    register char *dest = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf;
    register char *source = (yytext);
    register int number_to_move, i;
    int ret_val;
    if ((yy_c_buf_p) > &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars) +1])
        yy_fatal_error ("fatal flex scanner internal error--end of buffer missed");
    if ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_fill_buffer == 0) {
        if ((yy_c_buf_p) -(yytext)-0 == 1) {
            return 1;
        }
        else {
            return 2;
        }
    }
    number_to_move = (int) ((yy_c_buf_p) -(yytext)) - 1;
    for (i = 0; i < number_to_move; ++i)
        *(dest++) = *(source++);
    if ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status == 2)
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars) = 0;
    else {
        int num_to_read = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size - number_to_move - 1;
        while (num_to_read <= 0) {
            YY_BUFFER_STATE b = ((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0));
            int yy_c_buf_p_offset = (int) ((yy_c_buf_p) -b->yy_ch_buf);
            if (b->yy_is_our_buffer) {
                int new_size = b->yy_buf_size * 2;
                if (new_size <= 0)
                    b->yy_buf_size += b->yy_buf_size / 8;
                else
                    b->yy_buf_size *= 2;
                b->yy_ch_buf = (char *) yyrealloc ((void *) b->yy_ch_buf, b->yy_buf_size + 2);
            }
            else
                b->yy_ch_buf = 0;
            if (!b->yy_ch_buf)
                yy_fatal_error ("fatal error - scanner input buffer overflow");
            (yy_c_buf_p) = &b->yy_ch_buf[yy_c_buf_p_offset];
            num_to_read = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size - number_to_move - 1;
        }
        if (num_to_read > 8192)
            num_to_read = 8192;
        if ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_is_interactive) {
            int c = '*';
            int n;
            for (n = 0; n < (size_t) num_to_read && (c = _IO_getc (yyin)) != (-1) && c != '\n'; ++n)
                (&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move])[n] = (char) c;
            if (c == '\n')
                (&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move])[n++] = (char) c;
            if (c == (-1) && ferror (yyin))
                yy_fatal_error ("input in flex scanner failed");
            (yy_n_chars) = n;
        }
        else {
            (*__errno_location ()) = 0;
            while (((yy_n_chars) = fread ((&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move]), 1, (size_t) num_to_read, yyin)) == 0 && ferror (yyin)) {
                if ((*__errno_location ()) != 4) {
                    yy_fatal_error ("input in flex scanner failed");
                    break;
                }
                (*__errno_location ()) = 0;
                clearerr (yyin);
            }
        };
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
    }
    if ((yy_n_chars) == 0) {
        if (number_to_move == 0) {
            ret_val = 1;
            yyrestart (yyin);
        }
        else {
            ret_val = 2;
            (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status = 2;
        }
    }
    else
        ret_val = 0;
    if ((yy_size_t) ((yy_n_chars) +number_to_move) > (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size) {
        yy_size_t new_size = (yy_n_chars) +number_to_move + ((yy_n_chars) >> 1);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf = (char *) yyrealloc ((void *) (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf, new_size);
        if (!(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf)
            yy_fatal_error ("out of dynamic memory in yy_get_next_buffer()");
    }
    (yy_n_chars) += number_to_move;
    (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)] = 0;
    (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars) +1] = 0;
    (yytext) = &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[0];
    return ret_val;
}

yy_state_type yy_get_previous_state1 (void) {
    register yy_state_type yy_current_state;
    register char *yy_cp;
    yy_current_state = (yy_start);
    yy_current_state += ((yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol);
    for (yy_cp = (yytext) +0; yy_cp < (yy_c_buf_p); ++yy_cp) {
        register YY_CHAR yy_c = (*yy_cp ? yy_ec[((unsigned  int) (unsigned  char) *yy_cp)] : 1);
        if (yy_accept[yy_current_state]) {
            (yy_last_accepting_state) = yy_current_state;
            (yy_last_accepting_cpos) = yy_cp;
        }
        while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state) {
            yy_current_state = (int) yy_def[yy_current_state];
            if (yy_current_state >= 191)
                yy_c = yy_meta[(unsigned  int) yy_c];
        }
        yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned  int) yy_c];
    }
    return yy_current_state;
}

yy_state_type yy_try_NUL_trans1 (yy_state_type yy_current_state) {
    register int yy_is_jam;
    register char *yy_cp = (yy_c_buf_p);
    register YY_CHAR yy_c = 1;
    if (yy_accept[yy_current_state]) {
        (yy_last_accepting_state) = yy_current_state;
        (yy_last_accepting_cpos) = yy_cp;
    }
    while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state) {
        yy_current_state = (int) yy_def[yy_current_state];
        if (yy_current_state >= 191)
            yy_c = yy_meta[(unsigned  int) yy_c];
    }
    yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned  int) yy_c];
    yy_is_jam = (yy_current_state == 190);
    return yy_is_jam ? 0 : yy_current_state;
}

void yyunput (int c, register char *yy_bp) {
    register char *yy_cp;
    yy_cp = (yy_c_buf_p);
    *yy_cp = (yy_hold_char);
    if (yy_cp < (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf + 2) {
        register int number_to_move = (yy_n_chars) +2;
        register char *dest = &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size + 2];
        register char *source = &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move];
        while (source > (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf)
            *--dest = *--source;
        yy_cp += (int) (dest - source);
        yy_bp += (int) (dest - source);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size;
        if (yy_cp < (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf + 2)
            yy_fatal_error ("flex scanner push-back overflow");
    }
    *--yy_cp = (char) c;
    (yytext) = yy_bp;
    (yy_hold_char) = *yy_cp;
    (yy_c_buf_p) = yy_cp;
}

int input1 (void) {
    int c;
    *(yy_c_buf_p) = (yy_hold_char);
    if (*(yy_c_buf_p) == 0) {
        if ((yy_c_buf_p) < &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)])
            *(yy_c_buf_p) = '\0';
        else {
            int offset = (yy_c_buf_p) -(yytext);
            ++(yy_c_buf_p);
            switch (yy_get_next_buffer1 ()) {
            case 2 :
                yyrestart (yyin);
            case 1 :
                {
                    if (yywrap ())
                        return (-1);
                    if (!(yy_did_buffer_switch_on_eof))
                        yyrestart (yyin);
                    return input1 ();
                }
            case 0 :
                (yy_c_buf_p) = (yytext) +offset;
                break;
            }
        }
    }
    c = *(unsigned char*) (yy_c_buf_p);
    *(yy_c_buf_p) = '\0';
    (yy_hold_char) = *++(yy_c_buf_p);
    (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_at_bol = (c == '\n');
    return c;
}

void yyrestart (FILE *input_file) {
    if (!((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        yyensure_buffer_stack1 ();
        (yy_buffer_stack)[(yy_buffer_stack_top)] = yy_create_buffer (yyin, 16384);
    }
    yy_init_buffer1 (((yy_buffer_stack) ? (yy_buffer_stack) [(yy_buffer_stack_top)] : ((void *) 0)), input_file);
    yy_load_buffer_state1 ();
}

void yy_switch_to_buffer (YY_BUFFER_STATE new_buffer) {
    yyensure_buffer_stack1 ();
    if (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0)) == new_buffer)
        return;
    if (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        *(yy_c_buf_p) = (yy_hold_char);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos = (yy_c_buf_p);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
    }
    (yy_buffer_stack)[(yy_buffer_stack_top)] = new_buffer;
    yy_load_buffer_state1 ();
    (yy_did_buffer_switch_on_eof) = 1;
}

void yy_load_buffer_state1 (void) {
    (yy_n_chars) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars;
    (yytext) = (yy_c_buf_p) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos;
    yyin = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_input_file;
    (yy_hold_char) = *(yy_c_buf_p);
}

YY_BUFFER_STATE yy_create_buffer (FILE *file, int size) {
    YY_BUFFER_STATE b;
    b = (YY_BUFFER_STATE) yyalloc (sizeof (struct yy_buffer_state));
    if (!b)
        yy_fatal_error ("out of dynamic memory in yy_create_buffer()");
    b->yy_buf_size = size;
    b->yy_ch_buf = (char *) yyalloc (b->yy_buf_size + 2);
    if (!b->yy_ch_buf)
        yy_fatal_error ("out of dynamic memory in yy_create_buffer()");
    b->yy_is_our_buffer = 1;
    yy_init_buffer1 (b, file);
    return b;
}

void yy_delete_buffer (YY_BUFFER_STATE b) {
    if (!b)
        return;
    if (b == ((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0)))
        (yy_buffer_stack)[(yy_buffer_stack_top)] = (YY_BUFFER_STATE) 0;
    if (b->yy_is_our_buffer)
        yyfree ((void *) b->yy_ch_buf);
    yyfree ((void *) b);
}

extern int isatty (int);

void yy_init_buffer1 (YY_BUFFER_STATE b, FILE *file) {
    int oerrno = (*__errno_location ());
    yy_flush_buffer (b);
    b->yy_input_file = file;
    b->yy_fill_buffer = 1;
    if (b != ((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        b->yy_bs_lineno = 1;
        b->yy_bs_column = 0;
    }
    b->yy_is_interactive = file ? (isatty (fileno (file)) > 0) : 0;
    (*__errno_location ()) = oerrno;
}

void yy_flush_buffer (YY_BUFFER_STATE b) {
    if (!b)
        return;
    b->yy_n_chars = 0;
    b->yy_ch_buf[0] = 0;
    b->yy_ch_buf[1] = 0;
    b->yy_buf_pos = &b->yy_ch_buf[0];
    b->yy_at_bol = 1;
    b->yy_buffer_status = 0;
    if (b == ((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0)))
        yy_load_buffer_state1 ();
}

void yypush_buffer_state (YY_BUFFER_STATE new_buffer) {
    if (new_buffer == ((void *) 0))
        return;
    yyensure_buffer_stack1 ();
    if (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        *(yy_c_buf_p) = (yy_hold_char);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos = (yy_c_buf_p);
        (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
    }
    if (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0)))
        (yy_buffer_stack_top)++;
    (yy_buffer_stack)[(yy_buffer_stack_top)] = new_buffer;
    yy_load_buffer_state1 ();
    (yy_did_buffer_switch_on_eof) = 1;
}

void yypop_buffer_state (void) {
    if (!((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0)))
        return;
    yy_delete_buffer (((yy_buffer_stack) ? (yy_buffer_stack) [(yy_buffer_stack_top)] : ((void *) 0)));
    (yy_buffer_stack)[(yy_buffer_stack_top)] = ((void *) 0);
    if ((yy_buffer_stack_top) > 0)
        --(yy_buffer_stack_top);
    if (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        yy_load_buffer_state1 ();
        (yy_did_buffer_switch_on_eof) = 1;
    }
}

void yyensure_buffer_stack1 (void) {
    int num_to_alloc;
    if (!(yy_buffer_stack)) {
        num_to_alloc = 1;
        (yy_buffer_stack) = (struct yy_buffer_state **) yyalloc (num_to_alloc * sizeof (struct yy_buffer_state *));
        if (!(yy_buffer_stack))
            yy_fatal_error ("out of dynamic memory in yyensure_buffer_stack()");
        memset ((yy_buffer_stack), 0, num_to_alloc * sizeof (struct yy_buffer_state *));
        (yy_buffer_stack_max) = num_to_alloc;
        (yy_buffer_stack_top) = 0;
        return;
    }
    if ((yy_buffer_stack_top) >= ((yy_buffer_stack_max)) - 1) {
        int grow_size = 8;
        num_to_alloc = (yy_buffer_stack_max) +grow_size;
        (yy_buffer_stack) = (struct yy_buffer_state **) yyrealloc ((yy_buffer_stack), num_to_alloc * sizeof (struct yy_buffer_state *));
        if (!(yy_buffer_stack))
            yy_fatal_error ("out of dynamic memory in yyensure_buffer_stack()");
        memset ((yy_buffer_stack) + (yy_buffer_stack_max), 0, grow_size * sizeof (struct yy_buffer_state *));
        (yy_buffer_stack_max) = num_to_alloc;
    }
}

YY_BUFFER_STATE yy_scan_buffer (char *base, yy_size_t size) {
    YY_BUFFER_STATE b;
    if (size < 2 || base[size - 2] != 0 || base[size - 1] != 0)
        return 0;
    b = (YY_BUFFER_STATE) yyalloc (sizeof (struct yy_buffer_state));
    if (!b)
        yy_fatal_error ("out of dynamic memory in yy_scan_buffer()");
    b->yy_buf_size = size - 2;
    b->yy_buf_pos = b->yy_ch_buf = base;
    b->yy_is_our_buffer = 0;
    b->yy_input_file = 0;
    b->yy_n_chars = b->yy_buf_size;
    b->yy_is_interactive = 0;
    b->yy_at_bol = 1;
    b->yy_fill_buffer = 0;
    b->yy_buffer_status = 0;
    yy_switch_to_buffer (b);
    return b;
}

YY_BUFFER_STATE yy_scan_string (const char *yystr) {
    return yy_scan_bytes (yystr, strlen (yystr));
}

YY_BUFFER_STATE yy_scan_bytes (const char *yybytes, int _yybytes_len) {
    YY_BUFFER_STATE b;
    char *buf;
    yy_size_t n;
    int i;
    n = _yybytes_len + 2;
    buf = (char *) yyalloc (n);
    if (!buf)
        yy_fatal_error ("out of dynamic memory in yy_scan_bytes()");
    for (i = 0; i < _yybytes_len; ++i)
        buf[i] = yybytes[i];
    buf[_yybytes_len] = buf[_yybytes_len + 1] = 0;
    b = yy_scan_buffer (buf, n);
    if (!b)
        yy_fatal_error ("bad buffer in yy_scan_bytes()");
    b->yy_is_our_buffer = 1;
    return b;
}

void yy_fatal_error (const char *msg) {
    (void) fprintf (stderr, "%s\n", msg);
    exit (2);
}

int yyget_lineno (void) {
    return yylineno;
}

FILE *yyget_in (void) {
    return yyin;
}

FILE *yyget_out (void) {
    return yyout;
}

int yyget_leng (void) {
    return yyleng;
}

char *yyget_text (void) {
    return yytext;
}

void yyset_lineno (int line_number) {
    yylineno = line_number;
}

void yyset_in (FILE *in_str) {
    yyin = in_str;
}

void yyset_out (FILE *out_str) {
    yyout = out_str;
}

int yyget_debug (void) {
    return yy_flex_debug;
}

void yyset_debug (int bdebug) {
    yy_flex_debug = bdebug;
}

int yy_init_globals1 (void) {
    (yy_buffer_stack) = 0;
    (yy_buffer_stack_top) = 0;
    (yy_buffer_stack_max) = 0;
    (yy_c_buf_p) = (char *) 0;
    (yy_init) = 0;
    (yy_start) = 0;
    yyin = (FILE *) 0;
    yyout = (FILE *) 0;
    return 0;
}

int yylex_destroy (void) {
    while (((yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *) 0))) {
        yy_delete_buffer (((yy_buffer_stack) ? (yy_buffer_stack) [(yy_buffer_stack_top)] : ((void *) 0)));
        (yy_buffer_stack)[(yy_buffer_stack_top)] = ((void *) 0);
        yypop_buffer_state ();
    }
    yyfree ((yy_buffer_stack));
    (yy_buffer_stack) = ((void *) 0);
    yy_init_globals1 ();
    return 0;
}

void *yyalloc (yy_size_t size) {
    return (void *) malloc (size);
}

void *yyrealloc (void *ptr, yy_size_t size) {
    return (void *) realloc ((char *) ptr, size);
}

void yyfree (void *ptr) {
    free ((char *) ptr);
}

static char *keywords [] = {"break", "case", "continue", "default", "do", "else", "for", "goto", "if", "return", "sizeof", "switch", "while"};
static char *types [] = {"char", "double", "float", "int", "void",};
static char *qualifiers [] = {"long", "const", "register", "restrict", "short", "signed", "unsigned", "volatile", "inline"};

void init_tokens () {
    int i;
    Symbol *sp;
    for (i = 0; i < sizeof (keywords) / sizeof ((keywords)[0]); i++) {
        sp = install (keywords[i], 0x01);
        sp->type = SymToken;
        sp->token_type = 257;
    }
    for (i = 0; i < sizeof (types) / sizeof ((types)[0]); i++) {
        sp = install (types[i], 0x01);
        sp->type = SymToken;
        sp->token_type = 270;
        sp->source = ((void *) 0);
        sp->def_line = -1;
        sp->ref_line = ((void *) 0);
    }
    for (i = 0; i < sizeof (qualifiers) / sizeof ((qualifiers)[0]); i++) {
        sp = install (qualifiers[i], 0x01);
        sp->type = SymToken;
        sp->token_type = 273;
        sp->source = ((void *) 0);
        sp->def_line = -1;
        sp->ref_line = ((void *) 0);
    }
    sp = install ("...", 0x01);
    sp->type = SymToken;
    sp->token_type = 260;
    sp->source = ((void *) 0);
    sp->def_line = -1;
    sp->ref_line = ((void *) 0);
}

void init_lex (int debug_level) {
    yy_flex_debug = debug_level;
    _obstack_begin ((& string_stk), 0, 0, (void * (*) (long)) xmalloc, (void (*) (void *)) free);
    init_tokens ();
}

int ident () {
    if (prev_token != 264) {
        Symbol *sp = lookup (yytext);
        if (sp && sp->type == SymToken) {
            yylval.str = sp->name;
            return sp->token_type;
        }
    }
    __extension__ ({struct obstack * __o = (& string_stk); int __len = (yyleng); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, yytext, __len); __o -> next_free += __len; (void) 0;});
    __extension__ ({struct obstack * __o = (& string_stk); if (__o -> next_free + 1 > __o -> chunk_limit) _obstack_newchunk (__o, 1); (* ((__o) -> next_free) ++ = (0)); (void) 0;});
    yylval.str = __extension__ ({
        struct obstack *__o1 = (&string_stk);
        void *__value = (void *) __o1->object_base;
        if (__o1->next_free == __value)
            __o1->maybe_empty_object = 1;
        __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
        if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
            __o1->next_free = __o1->chunk_limit;
        __o1->object_base = __o1->next_free;
        __value;
    }
    );
    return 260;
}

char *pp_bin;
char *pp_opts;
static struct obstack *opt_stack;

void set_preprocessor (const char *arg) {
    pp_bin = arg ? xstrdup (arg) : ((void *) 0);
}

void pp_option (const char *arg) {
    if (!opt_stack) {
        if (!pp_bin)
            pp_bin = "/usr/bin/cpp";
        opt_stack = xmalloc (sizeof *opt_stack);
        _obstack_begin ((opt_stack), 0, 0, (void * (*) (long)) xmalloc, (void (*) (void *)) free);
    }
    __extension__ ({struct obstack * __o = (opt_stack); if (__o -> next_free + 1 > __o -> chunk_limit) _obstack_newchunk (__o, 1); (* ((__o) -> next_free) ++ = (' ')); (void) 0;});
    __extension__ ({struct obstack * __o = (opt_stack); int __len = (strlen (arg)); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, arg, __len); __o -> next_free += __len; (void) 0;});
}

void pp_finalize () {
    char *s = __extension__ ({
        struct obstack *__o1 = (opt_stack);
        void *__value = (void *) __o1->object_base;
        if (__o1->next_free == __value)
            __o1->maybe_empty_object = 1;
        __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
        if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
            __o1->next_free = __o1->chunk_limit;
        __o1->object_base = __o1->next_free;
        __value;
    }
    );
    if (!pp_opts)
        pp_opts = xstrdup (s);
    else {
        pp_opts = xrealloc (pp_opts, strlen (pp_opts) +strlen (s) + 1);
        strcat (pp_opts, s);
    }
    __extension__ ({struct obstack * __o = (opt_stack); void * __obj = (s); if (__obj > (void *) __o -> chunk && __obj < (void *) __o -> chunk_limit) __o -> next_free = __o -> object_base = (char *) __obj; else (obstack_free) (__o, __obj);});
    free (opt_stack);
    opt_stack = ((void *) 0);
}

FILE *pp_open (const char *name) {
    FILE *fp;
    char *s;
    size_t size;
    if (opt_stack)
        pp_finalize ();
    size = strlen (pp_bin) + 1 + strlen (name) + 1;
    if (pp_opts)
        size += strlen (pp_opts);
    s = xmalloc (size);
    strcpy (s, pp_bin);
    if (pp_opts)
        strcat (s, pp_opts);
    strcat (s, " ");
    strcat (s, name);
    if (debug)
        printf (((const char *) ("Command line: %s\n")), s);
    fp = popen (s, "r");
    if (!fp)
        error (0, (*__errno_location ()), ((const char *) ("cannot execute `%s'")), s);
    free (s);
    return fp;
}

void pp_close (FILE *fp) {
    pclose (fp);
}

int yywrap () {
    if (!yyin)
        return 1;
    if (preprocess_option)
        pp_close (yyin);
    else
        fclose (yyin);
    yyin = ((void *) 0);
    delete_statics ();
    return 1;
}

static int hit_eof;

int get_token () {
    int tok;
    if (hit_eof)
        tok = 0;
    else {
        tok = yylex ();
        prev_token = tok;
        if (!tok)
            hit_eof = 1;
    }
    return tok;
}

int source (char *name) {
    FILE *fp;
    fp = fopen (name, "r");
    if (!fp) {
        error (0, (* __errno_location ()), ((const char *) ("cannot open `%s'")), name);
        return 1;
    }
    if (preprocess_option) {
        fclose (fp);
        fp = pp_open (name);
        if (!fp)
            return 1;
    }
    __extension__ ({struct obstack * __o = (& string_stk); int __len = (strlen (name) + 1); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, name, __len); __o -> next_free += __len; (void) 0;});
    filename = __extension__ ({
        struct obstack *__o1 = (&string_stk);
        void *__value = (void *) __o1->object_base;
        if (__o1->next_free == __value)
            __o1->maybe_empty_object = 1;
        __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
        if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
            __o1->next_free = __o1->chunk_limit;
        __o1->object_base = __o1->next_free;
        __value;
    }
    );
    canonical_filename = filename;
    line_num = 1;
    input_file_count++;
    hit_eof = 0;
    yyrestart (fp);
    return 0;
}

int getnum1 (unsigned  base, int count) {
    int c, n;
    unsigned  i;
    for (n = 0; count; count--) {
        if (((*__ctype_b_loc ())[(int) ((c = input1 ()))] & (unsigned  short  int) _ISdigit))
            i = c - '0';
        else
            i = toupper (c) - 'A' + 10;
        if (i > base) {
            yyunput (c, (yytext));
            break;
        }
        n = n * base + i;
    }
    return n;
}

int backslash () {
    int c;
    switch (c = input1 ()) {
    case 'a' :
        return '\a';
    case 'b' :
        return '\b';
    case 'f' :
        return '\f';
    case 'n' :
        return '\n';
    case 'r' :
        return '\r';
    case 't' :
        return '\t';
    case 'x' :
        return getnum1 (16, 2);
    case '0' :
        return getnum1 (8, 3);
    }
    return c;
}

void update_loc () {
    char *p;
    for (p = strchr (yytext, '#') + 1; *p && ((*__ctype_b_loc ())[(int) ((*p))] & (unsigned  short  int) _ISspace); p++)
        ;
    if (p[0] == 'l')
        p += 4;
    line_num = strtoul (p, &p, 10);
    for (; *p && ((*__ctype_b_loc ())[(int) ((*p))] & (unsigned  short  int) _ISspace); p++)
        ;
    if (p[0] == '"') {
        int n;
        for (p++, n = 0; p[n] && p[n] != '"'; n++)
            ;
        __extension__ ({struct obstack * __o = (& string_stk); int __len = (n); if (__o -> next_free + __len > __o -> chunk_limit) _obstack_newchunk (__o, __len); memcpy (__o -> next_free, p, __len); __o -> next_free += __len; (void) 0;});
        __extension__ ({struct obstack * __o = (& string_stk); if (__o -> next_free + 1 > __o -> chunk_limit) _obstack_newchunk (__o, 1); (* ((__o) -> next_free) ++ = (0)); (void) 0;});
        filename = __extension__ ({
            struct obstack *__o1 = (&string_stk);
            void *__value = (void *) __o1->object_base;
            if (__o1->next_free == __value)
                __o1->maybe_empty_object = 1;
            __o1->next_free = ((sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (((__o1->next_free) - (sizeof (long  int) < sizeof (void *) ? (__o1->object_base) : (char *) 0) + (__o1->alignment_mask)) & ~(__o1->alignment_mask)));
            if (__o1->next_free - (char *) __o1->chunk > __o1->chunk_limit - (char *) __o1->chunk)
                __o1->next_free = __o1->chunk_limit;
            __o1->object_base = __o1->next_free;
            __value;
        }
        );
    }
    if (debug > 1)
        printf (((const char *) ("New location: %s:%d\n")), filename, line_num);
}


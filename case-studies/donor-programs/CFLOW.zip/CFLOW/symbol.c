
#include <cflow.h>

#include <parser.h>

#include <hash.h>
static Hash_table *symbol_table;
static struct linked_list *static_symbol_list;
static struct linked_list *auto_symbol_list;
static struct linked_list *static_func_list;

void append_symbol1 (struct linked_list **plist, Symbol *sp) {
    if (sp->entry) {
        linked_list_unlink (sp -> entry -> list, sp -> entry);
        sp->entry = NULL;
    }
    if (!data_in_list (sp, *plist)) {
        linked_list_append (plist, sp);
        sp->entry = (*plist)->tail;
    }
}

struct table_entry {
    Symbol *sym;
};

size_t hash_symbol_hasher1 (void const *data, unsigned  n_buckets) {
    struct table_entry const *t = data;
    if (!t->sym)
        return ((size_t) data) % n_buckets;
    return hash_string (t->sym->name, n_buckets);
}

bool hash_symbol_compare1 (void const *data1, void const *data2) {
    struct table_entry const *t1 = data1;
    struct table_entry const *t2 = data2;
    return t1->sym && t2->sym && strcmp (t1->sym->name, t2->sym->name) == 0;
}

Symbol *lookup (const char *name) {
    Symbol s, *sym;
    struct table_entry t, *tp;
    if (!symbol_table)
        return NULL;
    s.name = (char *) name;
    t.sym = &s;
    tp = hash_lookup (symbol_table, &t);
    if (tp) {
        sym = tp->sym;
        while (sym->type == SymToken && sym->flag == symbol_alias)
            sym = sym->alias;
    }
    else
        sym = NULL;
    return sym;
}

Symbol *install (char *name, int flags) {
    Symbol *sym;
    struct table_entry *tp, *ret;
    sym = xmalloc (sizeof (*sym));
    memset (sym, 0, sizeof (* sym));
    sym->type = SymUndefined;
    sym->name = name;
    tp = xmalloc (sizeof (*tp));
    tp->sym = sym;
    if (((flags & INSTALL_CHECK_LOCAL) && canonical_filename && strcmp (filename, canonical_filename)) || (flags & INSTALL_UNIT_LOCAL)) {
        sym->flag = symbol_temp;
        append_symbol1 (& static_symbol_list, sym);
    }
    else
        sym->flag = symbol_none;
    if (!((symbol_table || (symbol_table = hash_initialize (0, 0, hash_symbol_hasher1, hash_symbol_compare1, 0))) && (ret = hash_insert (symbol_table, tp))))
        xalloc_die ();
    if (ret != tp) {
        if (flags & INSTALL_OVERWRITE) {
            free (sym);
            free (tp);
            return ret->sym;
        }
        if (ret->sym->type != SymUndefined)
            sym->next = ret->sym;
        ret->sym = sym;
        free (tp);
    }
    sym->owner = ret;
    return sym;
}

void ident_change_storage (Symbol *sp, enum storage storage) {
    if (sp->storage == storage)
        return;
    if (sp->storage == StaticStorage)
        ;
    switch (storage) {
    case StaticStorage :
        append_symbol1 (&static_symbol_list, sp);
        break;
    case AutoStorage :
        append_symbol1 (&auto_symbol_list, sp);
        break;
    default :
        break;
    }
    sp->storage = storage;
}

Symbol *install_ident (char *name, enum storage storage) {
    Symbol *sp;
    sp = install (name, storage != AutoStorage ? INSTALL_CHECK_LOCAL : INSTALL_DEFAULT);
    sp->type = SymIdentifier;
    sp->arity = -1;
    sp->storage = ExternStorage;
    sp->decl = NULL;
    sp->source = NULL;
    sp->def_line = -1;
    sp->ref_line = NULL;
    sp->caller = sp->callee = NULL;
    sp->level = -1;
    ident_change_storage (sp, storage);
    return sp;
}

void unlink_symbol1 (Symbol *sym) {
    Symbol *s, *prev = NULL;
    struct table_entry *tp = sym->owner;
    for (s = tp->sym; s;) {
        Symbol *next = s->next;
        if (s == sym) {
            if (prev)
                prev->next = next;
            else
                tp->sym = next;
            break;
        }
        else
            prev = s;
        s = next;
    }
    sym->owner = NULL;
}

void delete_symbol1 (Symbol *sym) {
    unlink_symbol1 (sym);
    if (sym->ref_line == NULL && !(reverse_tree && sym->callee)) {
        linked_list_destroy (& sym -> ref_line);
        linked_list_destroy (& sym -> caller);
        linked_list_destroy (& sym -> callee);
        free (sym);
    }
}

void static_free1 (void *data) {
    Symbol *sym = data;
    struct table_entry *t = sym->owner;
    if (!t)
        return;
    if (sym->flag == symbol_temp)
        delete_symbol1 (sym);
    else {
        unlink_symbol1 (sym);
        if (symbol_is_function (sym))
            linked_list_append (&static_func_list, sym);
    }
}

void delete_statics () {
    if (static_symbol_list) {
        static_symbol_list->free_data = static_free1;
        linked_list_destroy (& static_symbol_list);
    }
}

int delete_level_autos (void *data, void *call_data) {
    int level = *(int*) call_data;
    Symbol *s = data;
    if (s->level == level) {
        delete_symbol1 (s);
        return 1;
    }
    return 0;
}

int delete_level_statics (void *data, void *call_data) {
    int level = *(int*) call_data;
    Symbol *s = data;
    if (s->level == level) {
        unlink_symbol1 (s);
        return 1;
    }
    return 0;
}

void delete_autos (int level) {
    linked_list_iterate (& auto_symbol_list, delete_level_autos, & level);
    linked_list_iterate (& static_symbol_list, delete_level_statics, & level);
}

struct collect_data {
    Symbol **sym;
    int (*sel) (Symbol *p);
    size_t index;
};

bool collect_processor1 (void *data, void *proc_data) {
    struct table_entry *t = data;
    struct collect_data *cd = proc_data;
    Symbol *s;
    for (s = t->sym; s; s = s->next) {
        if (cd->sel (s)) {
            if (cd->sym)
                cd->sym[cd->index] = s;
            cd->index++;
        }
    }
    return true;
}

size_t collect_symbols (Symbol ***return_sym, int (*sel) (Symbol *p), size_t reserved_slots) {
    struct collect_data cdata;
    cdata.sym = NULL;
    cdata.index = 0;
    cdata.sel = sel;
    hash_do_for_each (symbol_table, collect_processor1, & cdata);
    cdata.sym = calloc (cdata.index + reserved_slots, sizeof (*cdata.sym));
    if (!cdata.sym)
        xalloc_die ();
    cdata.index = 0;
    hash_do_for_each (symbol_table, collect_processor1, & cdata);
    *return_sym = cdata.sym;
    return cdata.index;
}

size_t collect_functions (Symbol ***return_sym) {
    Symbol **symbols;
    size_t num, snum;
    struct linked_list_entry *p;
    snum = 0;
    if (static_func_list)
        for (p = linked_list_head (static_func_list); p; p = p->next)
            snum++;
    num = collect_symbols (&symbols, symbol_is_function, snum);
    if (snum)
        for (p = linked_list_head (static_func_list); p; p = p->next)
            symbols[num++] = p->data;
    *return_sym = symbols;
    return num;
}

int delete_parms_itr (void *data, void *call_data) {
    int level = *(int*) call_data;
    Symbol *s = data;
    struct table_entry *t = s->owner;
    if (!t)
        return 1;
    if (s->type == SymIdentifier && s->storage == AutoStorage && s->flag == symbol_parm && s->level > level) {
        delete_symbol1 (s);
        return 1;
    }
    return 0;
}

void delete_parms (int level) {
    linked_list_iterate (& auto_symbol_list, delete_parms_itr, & level);
}

void move_parms (int level) {
    struct linked_list_entry *p;
    for (p = linked_list_head (auto_symbol_list); p; p = p->next) {
        Symbol *s = p->data;
        if (s->type == SymIdentifier && s->storage == AutoStorage && s->flag == symbol_parm) {
            s->level = level;
            s->flag = symbol_none;
        }
    }
}


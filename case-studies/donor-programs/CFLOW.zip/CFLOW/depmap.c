
#include <cflow.h>

#define CHAR_BIT 8

#define BITS_PER_WORD   (sizeof(unsigned)*CHAR_BIT)

#define WORDSIZE(n)     (((n) + BITS_PER_WORD - 1) / BITS_PER_WORD)

#define SETBIT(x, i)    ((x)[(i)/BITS_PER_WORD] |= (1<<((i) % BITS_PER_WORD)))

#define RESETBIT(x, i)  ((x)[(i)/BITS_PER_WORD] &= ~(1<<((i) % BITS_PER_WORD)))

#define BITISSET(x, i)  (((x)[(i)/BITS_PER_WORD] & (1<<((i) % BITS_PER_WORD))) != 0)

void transitive_closure1 (unsigned  *R, int n) {
    register size_t rowsize;
    register unsigned  mask;
    register unsigned  *rowj;
    register unsigned  *rp;
    register unsigned  *rend;
    register unsigned  *ccol;
    unsigned  *relend;
    unsigned  *cword;
    unsigned  *rowi;
    rowsize = WORDSIZE (n) * sizeof (unsigned );
    relend = (unsigned  *) ((char *) R + (n * rowsize));
    cword = R;
    mask = 1;
    rowi = R;
    while (rowi < relend) {
        ccol = cword;
        rowj = R;
        while (rowj < relend) {
            if (*ccol & mask) {
                rp = rowi;
                rend = (unsigned  *) ((char *) rowj + rowsize);
                while (rowj < rend)
                    *rowj++ |= *rp++;
            }
            else {
                rowj = (unsigned  *) ((char *) rowj + rowsize);
            }
            ccol = (unsigned  *) ((char *) ccol + rowsize);
        }
        mask <<= 1;
        if (mask == 0) {
            mask = 1;
            cword++;
        }
        rowi = (unsigned  *) ((char *) rowi + rowsize);
    }
}

struct cflow_depmap {
    size_t nrows;
    size_t rowlen;
    unsigned  r [1];
};

cflow_depmap_t depmap_alloc (size_t count) {
    size_t size = (count + BITS_PER_WORD - 1) / BITS_PER_WORD;
    cflow_depmap_t dmap = xzalloc (sizeof (*dmap) - 1 + count * size * sizeof (unsigned ));
    dmap->nrows = count;
    dmap->rowlen = size;
    return dmap;
}

unsigned  *depmap_rowptr1 (cflow_depmap_t dmap, size_t row) {
    return dmap->r + dmap->rowlen * row;
}

void depmap_set (cflow_depmap_t dmap, size_t row, size_t col) {
    unsigned  *rptr = depmap_rowptr1 (dmap, row);
    SETBIT (rptr, col);
}

int depmap_isset (cflow_depmap_t dmap, size_t row, size_t col) {
    unsigned  *rptr = depmap_rowptr1 (dmap, row);
    return BITISSET (rptr, col);
}

void depmap_tc (cflow_depmap_t dmap) {
    transitive_closure1 (dmap -> r, dmap -> nrows);
}


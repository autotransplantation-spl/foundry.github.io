These header files were originally taken from the iTerm2 project at
https://github.com/gnachman/iTerm2/tree/dff7c9faec90daa7f1974a57bb43d1c2d383892e/ThirdParty/CGSInternal

iTerm2 is licensed under the GPL version 2.
